<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Bakanlik Dashboard - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <span class="text-xl font-bold text-blue-600">BAKANLIK</span>
                    <span class="ml-4 px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {{ auth()->user()->bakanlik->ad ?? 'Bakanlik' }}
                    </span>
                </div>
                <div class="flex items-center gap-4">
                    <span class="text-sm text-gray-600">{{ auth()->user()->tamAd() }}</span>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-sm text-red-600 hover:text-red-800 font-medium">Cikis</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div class="px-4 py-6 sm:px-0">
            <div class="bg-white rounded-xl shadow-sm p-6">
                <h1 class="text-2xl font-bold text-gray-900 mb-4">Bakanlik Dashboard</h1>
                <p class="text-gray-600">Bakanlik yetkilisi olarak giris yaptiniz.</p>
            </div>
        </div>
    </main>
</body>
</html>
