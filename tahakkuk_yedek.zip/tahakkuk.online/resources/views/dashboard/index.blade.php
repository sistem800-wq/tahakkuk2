@extends('layouts.app')

@section('title', 'Dashboard')
@section('page_title', 'Dashboard')

@section('content')
<div class="row g-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="icon bg-primary bg-opacity-10 text-primary">
                <i class="bi bi-shield-fill"></i>
            </div>
            <div class="value">Super Admin</div>
            <div class="label">Hosgeldiniz, {{ auth()->user()->tamAd() }}</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="icon bg-success bg-opacity-10 text-success">
                <i class="bi bi-calendar-check"></i>
            </div>
            <div class="value">{{ now()->format('d.m.Y') }}</div>
            <div class="label">Bugun</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="icon bg-info bg-opacity-10 text-info">
                <i class="bi bi-clock"></i>
            </div>
            <div class="value">{{ now()->format('H:i') }}</div>
            <div class="label">Son Giris</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <div class="icon bg-warning bg-opacity-10 text-warning">
                <i class="bi bi-geo-alt"></i>
            </div>
            <div class="value">{{ request()->ip() }}</div>
            <div class="label">IP Adresiniz</div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-info-circle"></i> Sistem Bilgileri
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Kullanici Kodu:</strong> {{ auth()->user()->kod ?? auth()->user()->id }}</p>
                        <p><strong>Rol:</strong> {{ auth()->user()->rol->ad ?? 'Super Admin' }}</p>
                        <p><strong>Hiyerarsi:</strong> {{ auth()->user()->hiyerarsiMetni() }}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Email:</strong> {{ auth()->user()->email }}</p>
                        <p><strong>Telefon:</strong> {{ auth()->user()->telefon ?? '-' }}</p>
                        <p><strong>Son Giris:</strong> {{ auth()->user()->son_giris ? auth()->user()->son_giris->format('d.m.Y H:i') : '-' }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
