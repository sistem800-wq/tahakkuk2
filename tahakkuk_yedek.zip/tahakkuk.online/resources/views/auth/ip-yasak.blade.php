<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erisim Engellendi - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg { 
            background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 40%, #0ea5e9 100%); 
            min-height: 100vh;
        }
        .glass-card { 
            background: rgba(255,255,255,0.98); 
            border-radius: 24px; 
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35);
        }
        .animate-fade-in { animation: fadeIn 0.6s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center p-4">
    <div class="w-full max-w-lg animate-fade-in">
        <div class="glass-card p-8 text-center">
            <!-- Terminal Icon -->
            <div class="w-20 h-20 mx-auto mb-6 rounded-2xl bg-red-100 flex items-center justify-center">
                <i class="fas fa-terminal text-3xl text-red-600"></i>
            </div>

            <h1 class="text-2xl font-bold text-gray-900 mb-2">Erisim Engellendi</h1>
            <p class="text-gray-600 mb-6">Bu terminalden erisim saglayamazsiniz.</p>

            <!-- IP Bilgisi -->
            <div class="bg-gray-50 rounded-xl p-4 mb-6 text-left">
                <div class="flex items-center gap-3 mb-2">
                    <i class="fas fa-network-wired text-gray-400"></i>
                    <span class="text-sm font-semibold text-gray-700">IP Adresiniz</span>
                </div>
                <div class="text-lg font-mono font-bold text-red-600">{{ $ip ?? 'Bilinmiyor' }}</div>
                <p class="text-xs text-gray-500 mt-1">Bu IP adresi sistem tarafindan engellenmistir.</p>
            </div>

            <!-- Detaylar -->
            <div class="space-y-3 mb-6">
                <div class="flex items-start gap-3 text-sm text-gray-600">
                    <i class="fas fa-shield-halved text-red-500 mt-0.5"></i>
                    <span>Guvenlik politikalarimiz geregi bu IP adresinden erisim izni verilmemektedir.</span>
                </div>
                <div class="flex items-start gap-3 text-sm text-gray-600">
                    <i class="fas fa-envelope text-blue-500 mt-0.5"></i>
                    <span>Erisim izni icin sistem yoneticisi ile iletisime geciniz.</span>
                </div>
            </div>

            <!-- Butonlar -->
            <div class="flex gap-3 justify-center">
                <a href="mailto:admin@tahakkuk.online" class="px-6 py-2.5 rounded-xl bg-gray-100 text-gray-700 font-semibold text-sm hover:bg-gray-200 transition-colors flex items-center gap-2">
                    <i class="fas fa-envelope"></i>
                    Yonetici ile Iletisim
                </a>
                <a href="{{ route('login') }}" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold text-sm hover:shadow-lg transition-all flex items-center gap-2">
                    <i class="fas fa-arrow-left"></i>
                    Giris Sayfasina Don
                </a>
            </div>

            <!-- Footer -->
            <div class="mt-8 pt-4 border-t border-gray-200">
                <p class="text-xs text-gray-400">
                    <i class="fas fa-shield-halved mr-1"></i>
                    Tahakkuk.Online - Guvenli Sistem
                </p>
            </div>
        </div>
    </div>
</body>
</html>
