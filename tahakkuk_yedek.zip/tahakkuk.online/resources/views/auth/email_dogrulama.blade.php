@extends('layouts.auth')

@section('title', 'Email Dogrulama')

@section('content')
<div class="text-center mb-4">
    <i class="bi bi-envelope-check" style="font-size:3rem;color:var(--primary)"></i>
    <h4 class="mt-2">Email Dogrulama</h4>
    <p class="text-muted">Email adresinize dogrulama kodu gonderildi. Lutfen kodu girin.</p>
</div>

<form method="POST" action="{{ route('login.email.dogrulama.post') }}">
    @csrf
    <div class="mb-4">
        <label class="form-label">Dogrulama Kodu</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-key"></i></span>
            <input type="text" name="kod" class="form-control text-center" placeholder="000000" required maxlength="6" pattern="[0-9]{6}" inputmode="numeric">
        </div>
    </div>

    <button type="submit" class="btn btn-auth text-white">
        <i class="bi bi-check-circle"></i> Dogrula
    </button>
</form>

<div class="mt-3 text-center">
    <form method="POST" action="{{ route('login.email.gonder') }}" class="d-inline">
        @csrf
        <button type="submit" class="btn btn-link text-decoration-none" style="color:var(--primary)">
            <i class="bi bi-arrow-repeat"></i> Kodu tekrar gonder
        </button>
    </form>
</div>

<div class="mt-2 text-center">
    <a href="{{ route('login') }}" class="text-decoration-none" style="color:var(--primary)">
        <i class="bi bi-arrow-left"></i> Geri don
    </a>
</div>
@endsection
