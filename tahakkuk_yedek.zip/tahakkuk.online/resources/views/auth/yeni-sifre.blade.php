<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Şifre - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg { background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 40%, #0ea5e9 100%); min-height: 100vh; }
        .glass-card { background: rgba(255,255,255,0.98); border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); }
        .input-field { transition: all 0.2s ease; border: 2px solid #e2e8f0; }
        .input-field:focus { border-color: #0ea5e9; box-shadow: 0 0 0 4px rgba(14,165,233,0.1); outline: none; }
        .giris-btn { background: linear-gradient(135deg, #0284c7, #0ea5e9); transition: all 0.3s ease; box-shadow: 0 4px 20px rgba(14,165,233,0.4); }
        .giris-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(14,165,233,0.5); }
        .animate-fade-in { animation: fadeIn 0.6s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .password-strength { height: 4px; border-radius: 2px; transition: all 0.3s ease; }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center p-4">
    <div class="w-full max-w-md animate-fade-in">
        <!-- Logo -->
        <div class="text-center mb-6">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-lg mb-3">
                <i class="fas fa-shield-halved text-3xl text-white"></i>
            </div>
            <h1 class="text-2xl font-bold text-white mb-1">TAHAKKUK.ONLINE</h1>
            <p class="text-blue-200 text-sm">Yeni Şifre Belirleme</p>
        </div>

        <div class="glass-card p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
                <i class="fas fa-lock text-primary-500"></i>
                Yeni Şifre
            </h2>
            <p class="text-sm text-gray-500 mb-6">Lütfen yeni şifrenizi belirleyin. Şifreniz en az 6 karakter olmalıdır.</p>

            @if(session('error'))
                <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2">
                    <i class="fas fa-exclamation-circle"></i> {{ session('error') }}
                </div>
            @endif

            <form method="POST" action="{{ route('sifre.guncelle') }}" id="sifreForm">
                @csrf
                <input type="hidden" name="token" value="{{ $token }}">

                <!-- Yeni Şifre -->
                <div class="mb-4">
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">Yeni Şifre</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="password" name="sifre" id="sifre" class="w-full pl-11 pr-12 py-2.5 rounded-xl input-field text-sm" placeholder="Yeni şifreniz" required minlength="6" oninput="checkStrength()">
                        <button type="button" onclick="togglePassword('sifre', 'eye1')" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye" id="eye1"></i>
                        </button>
                    </div>
                    <!-- Şifre güçlülük çubuğu -->
                    <div class="mt-2">
                        <div class="flex justify-between text-xs text-gray-500 mb-1">
                            <span>Şifre Güçlülüğü</span>
                            <span id="strength-text">Zayıf</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-1">
                            <div class="password-strength bg-red-500" id="strength-bar" style="width: 0%"></div>
                        </div>
                    </div>
                </div>

                <!-- Şifre Tekrar -->
                <div class="mb-4">
                    <label class="block text-xs font-semibold text-gray-700 mb-1.5">Şifre Tekrar</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="password" name="sifre_confirmation" id="sifre_confirmation" class="w-full pl-11 pr-12 py-2.5 rounded-xl input-field text-sm" placeholder="Şifrenizi tekrar girin" required minlength="6">
                        <button type="button" onclick="togglePassword('sifre_confirmation', 'eye2')" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye" id="eye2"></i>
                        </button>
                    </div>
                </div>

                <!-- Şifre Kuralları -->
                <div class="mb-4 p-3 rounded-lg bg-gray-50 border border-gray-200">
                    <h4 class="text-xs font-bold text-gray-700 mb-2">Şifre Kuralları:</h4>
                    <ul class="space-y-1 text-xs text-gray-600">
                        <li class="flex items-center gap-2" id="rule-length">
                            <i class="fas fa-circle text-gray-300 text-[8px]"></i>
                            <span>En az 6 karakter</span>
                        </li>
                        <li class="flex items-center gap-2" id="rule-number">
                            <i class="fas fa-circle text-gray-300 text-[8px]"></i>
                            <span>En az 1 rakam</span>
                        </li>
                        <li class="flex items-center gap-2" id="rule-upper">
                            <i class="fas fa-circle text-gray-300 text-[8px]"></i>
                            <span>En az 1 büyük harf</span>
                        </li>
                    </ul>
                </div>

                <button type="submit" class="giris-btn w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2">
                    <i class="fas fa-save"></i>
                    <span>Şifreyi Güncelle</span>
                </button>
            </form>

            <!-- Geri Dön -->
            <div class="mt-6 text-center">
                <a href="{{ route('login') }}" class="text-sm text-primary-600 hover:text-primary-700 font-semibold flex items-center justify-center gap-2">
                    <i class="fas fa-arrow-left"></i>
                    Giriş Sayfasına Dön
                </a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(inputId, eyeId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(eyeId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        function checkStrength() {
            const sifre = document.getElementById('sifre').value;
            const bar = document.getElementById('strength-bar');
            const text = document.getElementById('strength-text');

            // Kuralları kontrol et
            const hasLength = sifre.length >= 6;
            const hasNumber = /\d/.test(sifre);
            const hasUpper = /[A-Z]/.test(sifre);

            // Kuralları güncelle
            updateRule('rule-length', hasLength);
            updateRule('rule-number', hasNumber);
            updateRule('rule-upper', hasUpper);

            // Güçlülük hesapla
            let strength = 0;
            if (hasLength) strength += 33;
            if (hasNumber) strength += 33;
            if (hasUpper) strength += 34;

            bar.style.width = strength + '%';

            if (strength < 33) {
                bar.className = 'password-strength bg-red-500';
                text.textContent = 'Zayıf';
                text.className = 'text-red-500';
            } else if (strength < 66) {
                bar.className = 'password-strength bg-yellow-500';
                text.textContent = 'Orta';
                text.className = 'text-yellow-500';
            } else {
                bar.className = 'password-strength bg-green-500';
                text.textContent = 'Güçlü';
                text.className = 'text-green-500';
            }
        }

        function updateRule(id, valid) {
            const rule = document.getElementById(id);
            const icon = rule.querySelector('i');
            if (valid) {
                icon.className = 'fas fa-check-circle text-green-500 text-[10px]';
                rule.classList.add('text-green-600');
            } else {
                icon.className = 'fas fa-circle text-gray-300 text-[8px]';
                rule.classList.remove('text-green-600');
            }
        }

        // Form doğrulama
        document.getElementById('sifreForm').addEventListener('submit', function(e) {
            const sifre = document.getElementById('sifre').value;
            const confirm = document.getElementById('sifre_confirmation').value;

            if (sifre !== confirm) {
                e.preventDefault();
                alert('Şifreler eşleşmiyor!');
                return false;
            }

            if (sifre.length < 6) {
                e.preventDefault();
                alert('Şifre en az 6 karakter olmalıdır!');
                return false;
            }
        });
    </script>
</body>
</html>
