<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Super Admin Giris - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 300: '#7dd3fc', 400: '#38bdf8', 500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e' },
                        dark: { 900: '#0f172a', 800: '#1e293b', 700: '#334155' }
                    }
                }
            }
        }
    </script>
    <style>
        .glass { background: rgba(255,255,255,0.95); backdrop-filter: blur(20px); }
        .gradient-bg { background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0ea5e9 100%); }
        .input-focus:focus { box-shadow: 0 0 0 3px rgba(14,165,233,0.15); border-color: #0ea5e9; }
        .animate-fade-in { animation: fadeIn 0.5s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="gradient-bg min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md animate-fade-in">
        <!-- Logo & Header -->
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-white/10 backdrop-blur-lg mb-4">
                <i class="fas fa-crown text-4xl text-purple-400"></i>
            </div>
            <h1 class="text-3xl font-bold text-white mb-2">SUPER ADMIN</h1>
            <p class="text-blue-200 text-lg">Tahakkuk.Online Yonetim</p>
        </div>

        <div class="glass rounded-3xl p-8 shadow-2xl">
            <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-lock text-purple-500 mr-3"></i>
                Guvenli Giris
            </h2>

            @if(session('success'))
                <div class="mb-4 p-4 rounded-xl bg-green-50 border border-green-200 text-green-700 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> {{ session('success') }}
                </div>
            @endif
            @if(session('error'))
                <div class="mb-4 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center">
                    <i class="fas fa-exclamation-circle mr-2"></i> {{ session('error') }}
                </div>
            @endif

            <form method="POST" action="{{ route('superadmin.login.post') }}">
                @csrf

                <!-- Email -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">E-posta Adresi</label>
                    <div class="relative">
                        <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="email" name="email" class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-300 input-focus outline-none transition-all" placeholder="superadmin@tahakkuk.online" required value="{{ old('email') }}">
                    </div>
                </div>

                <!-- Sifre -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sifre</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="password" name="sifre" id="sifreInput" class="w-full pl-12 pr-12 py-3 rounded-xl border border-gray-300 input-focus outline-none transition-all" placeholder="Sifreniz" required>
                        <button type="button" onclick="togglePassword()" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <!-- Beni Hatirla -->
                <div class="flex items-center justify-between mb-6">
                    <label class="flex items-center cursor-pointer">
                        <input type="checkbox" name="remember" class="w-4 h-4 text-primary-600 rounded border-gray-300 focus:ring-primary-500">
                        <span class="ml-2 text-sm text-gray-600">Beni hatirla</span>
                    </label>
                </div>

                <!-- Giris Butonu -->
                <button type="submit" class="w-full py-4 rounded-xl bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-lg shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-300 flex items-center justify-center gap-2">
                    <i class="fas fa-right-to-bracket"></i>
                    Giris Yap
                </button>
            </form>

            <!-- Geri Don -->
            <div class="mt-6 text-center">
                <a href="{{ route('login') }}" class="text-sm text-gray-500 hover:text-primary-600 transition-colors">
                    <i class="fas fa-arrow-left mr-1"></i>
                    Normal Giris Sayfasina Don
                </a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('sifreInput');
            const icon = document.getElementById('eyeIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>
</html>
