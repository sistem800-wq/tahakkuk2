@extends('layouts.auth')

@section('title', '2 Adimli Dogrulama')

@section('content')
<div class="text-center mb-4">
    <i class="bi bi-shield-lock" style="font-size:3rem;color:var(--primary)"></i>
    <h4 class="mt-2">2 Adimli Dogrulama</h4>
    <p class="text-muted">Google Authenticator uygulamanizdaki 6 haneli kodu girin.</p>
</div>

<form method="POST" action="{{ route('login.2fa.post') }}">
    @csrf
    <div class="mb-4">
        <label class="form-label">Dogrulama Kodu</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-shield-check"></i></span>
            <input type="text" name="kod" class="form-control text-center" placeholder="000000" required maxlength="6" pattern="[0-9]{6}" inputmode="numeric" autocomplete="one-time-code">
        </div>
    </div>

    <button type="submit" class="btn btn-auth text-white">
        <i class="bi bi-check-circle"></i> Dogrula
    </button>
</form>

<div class="mt-3 text-center">
    <a href="{{ route('login') }}" class="text-decoration-none" style="color:var(--primary)">
        <i class="bi bi-arrow-left"></i> Geri don
    </a>
</div>
@endsection
