<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Sıfırlama - Tahakkuk.Online</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #0f172a, #1e3a5f, #0ea5e9); padding: 40px 30px; text-align: center; }
        .header h1 { color: white; margin: 0; font-size: 24px; }
        .header p { color: #bae6fd; margin: 10px 0 0; }
        .content { padding: 40px 30px; }
        .content h2 { color: #1e293b; margin-top: 0; }
        .content p { color: #475569; line-height: 1.6; }
        .code-box { background: #f0f9ff; border: 2px dashed #0ea5e9; border-radius: 12px; padding: 20px; text-align: center; margin: 20px 0; }
        .code { font-size: 32px; font-weight: 800; color: #0369a1; letter-spacing: 8px; font-family: monospace; }
        .btn { display: inline-block; background: linear-gradient(135deg, #0284c7, #0ea5e9); color: white; text-decoration: none; padding: 16px 40px; border-radius: 12px; font-weight: 600; margin: 20px 0; }
        .footer { background: #f8fafc; padding: 20px 30px; text-align: center; border-top: 1px solid #e2e8f0; }
        .footer p { color: #94a3b8; font-size: 12px; margin: 0; }
        .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; margin: 20px 0; border-radius: 8px; }
        .warning p { color: #92400e; margin: 0; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 Tahakkuk.Online</h1>
            <p>Şifre Sıfırlama İsteği</p>
        </div>
        <div class="content">
            <h2>Merhaba,</h2>
            <p>Şifre sıfırlama isteği aldık. İşlemi tamamlamak için aşağıdaki yöntemlerden birini kullanabilirsiniz:</p>

            <div class="code-box">
                <p style="margin: 0 0 10px; color: #0369a1; font-weight: 600;">🔢 Sıfırlama Kodunuz</p>
                <div class="code">{{ $kod }}</div>
            </div>

            <p style="text-align: center;">Veya direkt link ile şifrenizi sıfırlayın:</p>
            <p style="text-align: center;">
                <a href="{{ $link }}" class="btn">Şifremi Sıfırla</a>
            </p>

            <div class="warning">
                <p>⚠️ Bu link ve kod 5 dakika içinde geçerliliğini yitirecektir. Güvenliğiniz için kimseyle paylaşmayın.</p>
            </div>

            <p>Eğer bu isteği siz yapmadıysanız, lütfen bu emaili dikkate almayın. Hesabınız güvende.</p>
        </div>
        <div class="footer">
            <p>© 2026 Tahakkuk.Online - Spor Tahakkuk Sistemi</p>
            <p style="margin-top: 8px;">Bu email otomatik olarak gönderilmiştir, lütfen yanıtlamayın.</p>
        </div>
    </div>
</body>
</html>