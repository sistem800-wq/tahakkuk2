<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Tahakkuk.Online') - Spor Tahakkuk Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root { --primary: #1a5f7a; --secondary: #159895; --dark: #0f4c5c; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: linear-gradient(135deg, var(--dark) 0%, var(--primary) 50%, var(--secondary) 100%); min-height: 100vh; }
        .auth-card { background: rgba(255,255,255,0.95); border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .auth-logo { text-align: center; margin-bottom: 30px; }
        .auth-logo i { font-size: 3.5rem; color: var(--primary); }
        .auth-logo h2 { color: var(--dark); font-weight: bold; }
        .form-control, .form-select { border-radius: 12px; padding: 14px 18px; border: 2px solid #e8e8e8; }
        .form-control:focus, .form-select:focus { border-color: var(--primary); box-shadow: 0 0 0 0.2rem rgba(26,95,122,0.15); }
        .btn-auth { background: var(--primary); border: none; border-radius: 12px; padding: 14px; font-weight: 600; font-size: 1.1rem; width: 100%; }
        .btn-auth:hover { background: var(--dark); }
        .hiyerarsi-btn { border-radius: 12px; padding: 15px; border: 2px solid #e8e8e8; background: white; cursor: pointer; transition: all 0.3s; text-align: left; }
        .hiyerarsi-btn:hover { border-color: var(--primary); background: #f0f7ff; }
        .hiyerarsi-btn.active { border-color: var(--primary); background: var(--primary); color: white; }
        .hiyerarsi-btn i { font-size: 1.5rem; margin-right: 12px; }
    </style>
    @yield('css')
</head>
<body class="d-flex align-items-center justify-content-center p-3">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="auth-card p-4 p-md-5">
                    <div class="auth-logo">
                        <i class="bi bi-shield-lock-fill"></i>
                        <h2>TAHAKKUK.ONLINE</h2>
                        <p>Spor Tahakkuk Yonetim Sistemi</p>
                    </div>

                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif
                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @yield('content')
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @yield('js')
</body>
</html>
