<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }}</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; }
        .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background: #f2f2f2; }
        .badge { background: #007bff; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }
    </style>
</head>
<body>
    <div class="success">
        <h2>✅ {{ $message }}</h2>
        <p>Sunucu Tarihi: <strong>{{ $tarih }}</strong></p>
    </div>

    <div class="info">
        <h3>Blade Direktif Testleri:</h3>
        <ul>
            <li>If testi: {{ true ? 'Calisiyor' : 'Calismiyor' }}</li>
            <li>Foreach testi: Asagidaki tablo</li>
            <li>PHP Blok: @php $test = "PHP Blok Calisiyor"; @endphp {{ $test }}</li>
        </ul>
    </div>

    <h3>Kullanici Listesi (Foreach Testi)</h3>
    <table>
        <thead>
            <tr><th>#</th><th>Ad</th><th>Rol</th><th>Islem</th></tr>
        </thead>
        <tbody>
            @forelse($kullanicilar as $index => $kullanici)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $kullanici['ad'] }}</td>
                    <td><span class="badge">{{ $kullanici['rol'] }}</span></td>
                    <td>
                        @if($kullanici['rol'] == 'İl Müdürü')
                            Kirmizi Yonetici
                        @else
                            Yesil Standart
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="4">Veri yok</td></tr>
            @endforelse
        </tbody>
    </table>

    <div style="margin-top: 30px; padding: 15px; background: #fff3cd; border-radius: 5px;">
        <h4>Laravel Bilgileri:</h4>
        <p>Laravel Surumu: {{ app()->version() }}</p>
        <p>PHP Surumu: {{ PHP_VERSION }}</p>
        <p>Environment: {{ app()->environment() }}</p>
    </div>
</body>
</html>