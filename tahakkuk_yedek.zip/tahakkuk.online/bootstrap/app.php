<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\CheckService;
use App\Http\Middleware\IpKontrolMiddleware;
use App\Http\Middleware\HiyerarsiKontrol;
use App\Http\Middleware\AktifKontrol;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'check.service' => CheckService::class,
            'ip.kontrol' => IpKontrolMiddleware::class,
            'hiyerarsi' => HiyerarsiKontrol::class,
            'aktif' => AktifKontrol::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
