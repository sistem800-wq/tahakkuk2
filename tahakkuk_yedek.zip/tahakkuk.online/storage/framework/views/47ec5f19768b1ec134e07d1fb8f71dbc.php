<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifremi Unuttum - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg { background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 40%, #0ea5e9 100%); min-height: 100vh; }
        .glass-card { background: rgba(255,255,255,0.98); border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); }
        .input-field { transition: all 0.2s ease; border: 2px solid #e2e8f0; }
        .input-field:focus { border-color: #0ea5e9; box-shadow: 0 0 0 4px rgba(14,165,233,0.1); outline: none; }
        .tab-btn { transition: all 0.3s ease; border: 2px solid #e2e8f0; background: #f8fafc; }
        .tab-btn.active { border-color: #0ea5e9; background: linear-gradient(135deg, #0ea5e9, #0284c7); color: white; box-shadow: 0 4px 12px rgba(14,165,233,0.3); }
        .giris-btn { background: linear-gradient(135deg, #0284c7, #0ea5e9); transition: all 0.3s ease; box-shadow: 0 4px 20px rgba(14,165,233,0.4); }
        .giris-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(14,165,233,0.5); }
        .animate-fade-in { animation: fadeIn 0.6s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .countdown-box { background: linear-gradient(135deg, #fef3c7, #fde68a); border: 2px solid #f59e0b; border-radius: 12px; padding: 16px; text-align: center; }
        .countdown-number { font-size: 2rem; font-weight: 800; color: #b45309; font-variant-numeric: tabular-nums; }
        .code-input { letter-spacing: 0.5em; font-size: 1.5rem; text-align: center; font-weight: 700; }
        .logo-sidebar { text-align: center; padding: 20px 0; border-top: 1px solid #e2e8f0; margin-top: auto; }
        .logo-img { width: 60px; height: 60px; margin: 0 auto 8px; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1)); }
        .hidden-section { display: none !important; }

        @media (max-width: 768px) {
            .desktop-sidebar { display: none !important; }
            .mobile-logo { display: block !important; text-align: center; margin-bottom: 20px; }
        }
        @media (min-width: 769px) {
            .desktop-sidebar { display: flex !important; flex-direction: column; }
            .mobile-logo { display: none !important; }
        }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center p-3 md:p-6">
    <!-- Mobil Logo -->
    <div class="mobile-logo w-full max-w-lg">
        <div class="text-center mb-4">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-lg mb-3">
                <img src="<?php echo e(asset('images/icons8-ball-64.png')); ?>" alt="Spor2023" class="w-12 h-12" 
                     onerror="this.onerror=null; this.parentElement.innerHTML='<i class=\'fas fa-basketball text-3xl text-orange-500\'></i>';">
            </div>
            <h1 class="text-2xl font-bold text-white mb-1">TAHAKKUK.ONLINE</h1>
            <p class="text-blue-200 text-sm">Şifre Sıfırlama</p>
        </div>
    </div>

    <div class="w-full max-w-5xl animate-fade-in">
        <div class="glass-card p-4 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-4 md:gap-6">
                <!-- SOL: Desktop Logo + Bilgi -->
                <div class="desktop-sidebar flex-col h-full">
                    <div class="flex-1">
                        <div class="text-center mb-6">
                            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 mb-3 shadow-lg">
                                <img src="<?php echo e(asset('images/icons8-ball-64.png')); ?>" alt="Spor2023" class="w-12 h-12" 
                                     onerror="this.onerror=null; this.parentElement.innerHTML='<i class=\'fas fa-basketball text-3xl text-white\'></i>';">
                            </div>
                            <h3 class="text-lg font-bold text-gray-800">TAHAKKUK</h3>
                            <p class="text-xs text-gray-500">Spor Tahakkuk Sistemi</p>
                        </div>

                        <div class="bg-blue-50 rounded-xl p-4 mb-4">
                            <h4 class="text-xs font-bold text-blue-700 mb-2">🔐 Şifre Sıfırlama</h4>
                            <p class="text-xs text-blue-600 leading-relaxed">
                                Email adresinize gönderilen 6 haneli kodu girerek şifrenizi sıfırlayabilirsiniz.
                            </p>
                        </div>

                        <div class="bg-amber-50 rounded-xl p-4">
                            <h4 class="text-xs font-bold text-amber-700 mb-2">⏰ Süre Limiti</h4>
                            <p class="text-xs text-amber-600 leading-relaxed">
                                Kod 5 dakika içinde geçerlidir. Süre dolduğunda yeni kod talep edin.
                            </p>
                        </div>
                    </div>

                    <!-- Logo -->
                    <div class="logo-sidebar">
                        <img src="<?php echo e(asset('images/icons8-ball-64.png')); ?>" alt="Spor2023" class="logo-img" 
                             onerror="this.onerror=null; this.style.display='none';">
                        <div class="text-sm font-bold text-gray-800">Spor2023 Web</div>
                        <div class="text-xs text-gray-500">V.2026.06.03</div>
                        <a href="https://sistem80.com.tr" target="_blank" class="text-xs text-primary-600 hover:text-primary-700 font-medium mt-1 inline-block">
                            Sistem Yazılım
                        </a>
                    </div>
                </div>

                <!-- SAĞ: Form -->
                <div>
                    <?php if(!session('success')): ?>
                        <h2 class="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
                            <i class="fas fa-key text-primary-500"></i>
                            Şifremi Unuttum
                        </h2>
                        <p class="text-sm text-gray-500 mb-6">Email adresiniz veya telefon numaranız ile şifrenizi sıfırlayabilirsiniz.</p>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                        <div class="mb-4 p-4 rounded-xl bg-green-50 border border-green-200">
                            <div class="flex items-start gap-3">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 text-xl"></i>
                                <div class="flex-1">
                                    <p class="text-green-700 text-sm font-semibold mb-3"><?php echo e(session('success')); ?></p>

                                    <!-- Geri Sayım -->
                                    <div class="countdown-box mb-4">
                                        <p class="text-xs text-amber-700 font-semibold mb-1">⏰ Kalan Süre</p>
                                        <div class="countdown-number" id="countdown">05:00</div>
                                        <p class="text-xs text-amber-600 mt-1">Bu süre içinde işlem yapmalısınız</p>
                                    </div>

                                    <!-- Kod Girişi -->
                                    <div class="bg-white border border-gray-200 rounded-xl p-4">
                                        <p class="text-xs font-semibold text-gray-700 mb-3">📱 Email adresinize gönderilen 6 haneli kodu girin:</p>
                                        <form method="GET" action="<?php echo e(url('/sifre-sifirlama/kod')); ?>" class="flex gap-2">
                                            <input type="text" name="kod" placeholder="000000" maxlength="6" 
                                                class="code-input w-full px-4 py-3 rounded-xl input-field border-2 border-gray-200 focus:border-sky-500 outline-none"
                                                pattern="[0-9]{6}" inputmode="numeric" required>
                                            <button type="submit" class="giris-btn px-6 py-3 rounded-xl text-white font-bold whitespace-nowrap">
                                                <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <script>
                            let timeLeft = 300;
                            const countdownEl = document.getElementById('countdown');

                            const timer = setInterval(() => {
                                timeLeft--;
                                const minutes = Math.floor(timeLeft / 60);
                                const seconds = timeLeft % 60;
                                countdownEl.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

                                if (timeLeft <= 0) {
                                    clearInterval(timer);
                                    countdownEl.textContent = 'SÜRE DOLDU';
                                    countdownEl.style.color = '#dc2626';
                                    document.querySelector('input[name="kod"]')?.setAttribute('disabled', 'disabled');
                                }
                            }, 1000);
                        </script>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2">
                            <i class="fas fa-exclamation-circle"></i> <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!session('success')): ?>
                        <!-- Email/Telefon Seçimi -->
                        <div class="flex gap-2 mb-4" id="tab-buttons">
                            <button type="button" onclick="switchTab('email')" id="tab-email" class="tab-btn active flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2">
                                <i class="fas fa-envelope"></i>
                                <span>E-Posta</span>
                            </button>
                            <button type="button" onclick="switchTab('telefon')" id="tab-telefon" class="tab-btn flex-1 py-3 rounded-xl text-sm font-bold text-gray-600 flex items-center justify-center gap-2">
                                <i class="fas fa-mobile-screen"></i>
                                <span>SMS</span>
                            </button>
                        </div>

                        <!-- Email Form -->
                        <form method="POST" action="<?php echo e(route('sifre.sifirlama.email')); ?>" id="email-form">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">E-posta Adresi</label>
                                <div class="relative">
                                    <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                    <input type="email" name="email" class="w-full pl-11 pr-4 py-2.5 rounded-xl input-field text-sm" placeholder="ornek@email.com" required value="<?php echo e(old('email')); ?>">
                                </div>
                            </div>
                            <button type="submit" class="giris-btn w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2">
                                <i class="fas fa-paper-plane"></i>
                                <span>Link Gönder</span>
                            </button>
                        </form>

                        <!-- Telefon Form -->
                        <form method="POST" action="<?php echo e(route('sifre.sifirlama.sms')); ?>" id="telefon-form" class="hidden">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">Cep Telefonu</label>
                                <div class="relative">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-xs">+90</span>
                                    <input type="tel" name="telefon" class="w-full pl-12 pr-4 py-2.5 rounded-xl input-field text-sm" placeholder="532 123 45 67" maxlength="10" required value="<?php echo e(old('telefon')); ?>">
                                </div>
                                <p class="text-xs text-gray-500 mt-1">Başında 0 olmadan giriniz</p>
                            </div>
                            <button type="submit" class="giris-btn w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2">
                                <i class="fas fa-sms"></i>
                                <span>SMS Kod Gönder</span>
                            </button>
                        </form>
                    <?php endif; ?>

                    <!-- Geri Dön -->
                    <div class="mt-6 text-center">
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-primary-600 hover:text-primary-700 font-semibold flex items-center justify-center gap-2">
                            <i class="fas fa-arrow-left"></i>
                            Giriş Sayfasına Dön
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function switchTab(tab) {
            const emailTab = document.getElementById('tab-email');
            const telefonTab = document.getElementById('tab-telefon');
            const emailForm = document.getElementById('email-form');
            const telefonForm = document.getElementById('telefon-form');

            if (tab === 'email') {
                emailTab.classList.add('active');
                telefonTab.classList.remove('active');
                emailForm.classList.remove('hidden');
                telefonForm.classList.add('hidden');
            } else {
                telefonTab.classList.add('active');
                emailTab.classList.remove('active');
                telefonForm.classList.remove('hidden');
                emailForm.classList.add('hidden');
            }
        }

        document.querySelector('input[name="telefon"]')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 10) value = value.slice(0, 10);
            e.target.value = value;
        });
    </script>
</body>
</html><?php /**PATH /home/tahakkuk/domains/tahakkuk.online/resources/views/auth/sifre-sifirlama.blade.php ENDPATH**/ ?>