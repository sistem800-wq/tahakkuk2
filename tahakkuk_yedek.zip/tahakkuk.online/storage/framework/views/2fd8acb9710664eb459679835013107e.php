<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Giriş Yap - Tahakkuk.Online</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { -webkit-tap-highlight-color: transparent; }
        body { font-family: 'Inter', sans-serif; }
        .gradient-bg { 
            background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 40%, #0ea5e9 100%); 
            min-height: 100vh;
        }
        .glass-card { 
            background: rgba(255,255,255,0.98); 
            border-radius: 24px; 
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.1);
        }
        .input-field {
            transition: all 0.2s ease;
            border: 2px solid #e2e8f0;
        }
        .input-field:focus { 
            border-color: #0ea5e9; 
            box-shadow: 0 0 0 4px rgba(14,165,233,0.1);
            outline: none;
        }
        .role-btn { 
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #e2e8f0;
            background: #f8fafc;
            position: relative;
            overflow: hidden;
        }
        .role-btn::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: transparent;
            transition: all 0.3s ease;
        }
        .role-btn:hover { 
            background: #f1f5f9; 
            transform: translateX(4px);
            border-color: #cbd5e1;
        }
        .role-btn.active { 
            border-color: #0ea5e9; 
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
            box-shadow: 0 4px 16px rgba(14,165,233,0.2);
        }
        .role-btn.active::before {
            background: #0ea5e9;
        }
        .role-btn.active .check-icon { 
            color: #0ea5e9; 
            transform: scale(1);
            opacity: 1;
        }
        .check-icon {
            transition: all 0.3s ease;
            transform: scale(0.8);
            opacity: 0.5;
        }
        .giris-btn {
            background: linear-gradient(135deg, #0284c7, #0ea5e9);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 20px rgba(14,165,233,0.4);
            position: relative;
            overflow: hidden;
        }
        .giris-btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }
        .giris-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(14,165,233,0.5);
        }
        .giris-btn:hover::after {
            left: 100%;
        }
        .giris-btn:active {
            transform: translateY(0);
        }
        .tab-btn {
            transition: all 0.3s ease;
            border: 2px solid #e2e8f0;
            background: #f8fafc;
        }
        .tab-btn.active {
            border-color: #0ea5e9;
            background: linear-gradient(135deg, #0ea5e9, #0284c7);
            color: white;
            box-shadow: 0 4px 12px rgba(14,165,233,0.3);
        }
        .tab-btn:not(.active):hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
        }
        .animate-fade-in { 
            animation: fadeIn 0.6s cubic-bezier(0.4, 0, 0.2, 1); 
        }
        @keyframes fadeIn { 
            from { opacity: 0; transform: translateY(20px); } 
            to { opacity: 1; transform: translateY(0); } 
        }
        .logo-container {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid #e2e8f0;
            margin-top: auto;
        }
        .logo-img {
            width: 60px;
            height: 60px;
            margin: 0 auto 8px;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));
        }

        /* Toast Styles */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 400px;
        }
        .toast {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px 20px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transform: translateX(120%);
            transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            opacity: 0;
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
        }
        .toast.show {
            transform: translateX(0);
            opacity: 1;
        }
        .toast.hide {
            transform: translateX(120%);
            opacity: 0;
        }
        .toast-success { background: rgba(16, 185, 129, 0.95); color: white; border-left: 4px solid #059669; }
        .toast-error { background: rgba(239, 68, 68, 0.95); color: white; border-left: 4px solid #dc2626; }
        .toast-warning { background: rgba(245, 158, 11, 0.95); color: white; border-left: 4px solid #d97706; }
        .toast-info { background: rgba(59, 130, 246, 0.95); color: white; border-left: 4px solid #2563eb; }
        .toast-icon { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.2); flex-shrink: 0; }
        .toast-icon i { font-size: 16px; }
        .toast-content { flex: 1; }
        .toast-title { font-weight: 700; font-size: 14px; margin-bottom: 2px; }
        .toast-message { font-size: 13px; opacity: 0.9; }
        .toast-close { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.2); cursor: pointer; transition: all 0.2s ease; flex-shrink: 0; }
        .toast-close:hover { background: rgba(255,255,255,0.3); transform: rotate(90deg); }
        .toast-close i { font-size: 12px; color: white; }
        .toast-progress { position: absolute; bottom: 0; left: 0; height: 3px; background: rgba(255,255,255,0.4); border-radius: 0 0 12px 12px; transition: width linear; }

        @media (max-width: 768px) {
            .desktop-sidebar { display: none !important; }
            .mobile-tabs { display: flex !important; }
            .form-grid { grid-template-columns: 1fr !important; }
            .glass-card { border-radius: 16px; margin: 8px; }
            .input-field { padding: 12px 14px; font-size: 16px; }
            .toast-container { top: 10px; right: 10px; left: 10px; max-width: none; }
            .toast { padding: 12px 16px; }
        }
        @media (min-width: 769px) {
            .desktop-sidebar { display: flex !important; flex-direction: column; }
            .mobile-tabs { display: none !important; }
        }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center p-3 md:p-6">
    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <div class="w-full max-w-5xl animate-fade-in">
        <!-- Ana Container -->
        <div class="glass-card p-4 md:p-8">
            <div class="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-4 md:gap-6">
                <!-- SOL: Desktop Rol Seçimi + Logo -->
                <div class="desktop-sidebar flex-col h-full">
                    <div class="flex-1">
                        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">Kurum Seçimi</h3>

                        <button type="button" onclick="selectRole('bakanlik', this)" class="role-btn active w-full p-3 rounded-xl flex items-center gap-3 text-left mb-2">
                            <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center text-white shrink-0 shadow-md">
                                <i class="fas fa-building text-sm"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-gray-800 text-sm">Bakanlık</div>
                                <div class="text-xs text-gray-500">Yetkili</div>
                            </div>
                            <i class="fas fa-check-circle check-icon text-sm"></i>
                        </button>

                        <button type="button" onclick="selectRole('il_muduru', this)" class="role-btn w-full p-3 rounded-xl flex items-center gap-3 text-left mb-2">
                            <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shrink-0 shadow-md">
                                <i class="fas fa-map-location-dot text-sm"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-gray-800 text-sm">İl Müdürü</div>
                                <div class="text-xs text-gray-500">İl Müdürlüğü</div>
                            </div>
                            <i class="fas fa-check-circle check-icon text-gray-300 text-sm"></i>
                        </button>

                        <button type="button" onclick="selectRole('ilce_muduru', this)" class="role-btn w-full p-3 rounded-xl flex items-center gap-3 text-left mb-2">
                            <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-white shrink-0 shadow-md">
                                <i class="fas fa-shop text-sm"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-gray-800 text-sm">İlçe Müdürü</div>
                                <div class="text-xs text-gray-500">İlçe Müdürlüğü</div>
                            </div>
                            <i class="fas fa-check-circle check-icon text-gray-300 text-sm"></i>
                        </button>

                        <!-- Super Admin -->
                        <div class="pt-3 mt-2 border-t border-gray-200">
                            <a href="<?php echo e(route('superadmin.login')); ?>" class="flex items-center gap-2 text-xs text-gray-500 hover:text-primary-600 transition-colors p-2 rounded-lg hover:bg-gray-50">
                                <i class="fas fa-crown text-yellow-500"></i>
                                <span class="font-medium">Super Admin</span>
                            </a>
                        </div>
                    </div>

                    <!-- Logo -->
                    <div class="logo-container">
                        <img src="<?php echo e(asset('images/icons8-ball-64.png')); ?>" alt="Spor2023" class="logo-img" onerror="this.style.display='none'">
                        <div class="text-sm font-bold text-gray-800">Spor2023 Web</div>
                        <div class="text-xs text-gray-500">V.2026.06.03</div>
                        <a href="https://sistem80.com.tr" target="_blank" class="text-xs text-primary-600 hover:text-primary-700 font-medium mt-1 inline-block">
                            Sistem Yazılım
                        </a>
                    </div>
                </div>

                <!-- SAĞ: Form -->
                <div>
                    <!-- Mobil Tab'lar -->
                    <div class="mobile-tabs flex gap-2 mb-4 md:hidden">
                        <button type="button" onclick="selectRole('bakanlik', this)" class="tab-btn active flex-1 py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1">
                            <i class="fas fa-building text-lg"></i>
                            <span>Bakanlık</span>
                        </button>
                        <button type="button" onclick="selectRole('il_muduru', this)" class="tab-btn flex-1 py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 text-gray-600">
                            <i class="fas fa-map-location-dot text-lg"></i>
                            <span>İl Müd.</span>
                        </button>
                        <button type="button" onclick="selectRole('ilce_muduru', this)" class="tab-btn flex-1 py-3 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 text-gray-600">
                            <i class="fas fa-shop text-lg"></i>
                            <span>İlçe Müd.</span>
                        </button>
                    </div>

                    <h2 class="text-lg md:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <div class="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center">
                            <i class="fas fa-right-to-bracket text-primary-600 text-sm"></i>
                        </div>
                        Giriş Bilgileri
                    </h2>

                    <form method="POST" action="<?php echo e(route('login.post')); ?>" id="loginForm">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="kullanici_turu" id="kullanici_turu" value="bakanlik">
                        <input type="hidden" name="giris_turu" id="giris_turu" value="email">

                        <!-- Form Sıralama: Bakanlık → İl → İlçe → Birim → Email/Telefon → Şifre -->
                        <div class="form-grid grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                            <!-- 1. Bakanlık -->
                            <div class="md:col-span-2">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">Bakanlık <span class="text-red-500">*</span></label>
                                <select name="bakanlik_id" id="bakanlik_select" onchange="bakanlikDegisti()" class="w-full px-4 py-2.5 rounded-xl input-field text-sm bg-white">
                                    <option value="">Bakanlık Seçiniz</option>
                                    <?php $__currentLoopData = $bakanliklar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($b->id); ?>" <?php echo e(old('bakanlik_id') == $b->id ? 'selected' : ''); ?>><?php echo e($b->ad); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- 2. İl Müdürlüğü (İl ve İlçe Müdürü için) -->
                            <div id="il_secimi" style="display:none;">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">İl Müdürlüğü <span class="text-red-500">*</span></label>
                                <select name="il_mudurluk_id" id="il_select" onchange="ilDegisti()" class="w-full px-4 py-2.5 rounded-xl input-field text-sm bg-white">
                                    <option value="">İl Seçiniz</option>
                                    <?php $__currentLoopData = $il_mudurlukleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $il): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($il->id); ?>" data-bakanlik="<?php echo e($il->bakanlik_id); ?>" <?php echo e(old('il_mudurluk_id') == $il->id ? 'selected' : ''); ?>><?php echo e($il->ad); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- 3. İlçe Müdürlüğü (İlçe Müdürü için) -->
                            <div id="ilce_secimi" style="display:none;">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">İlçe Müdürlüğü <span class="text-red-500">*</span></label>
                                <select name="ilce_mudurluk_id" id="ilce_select" class="w-full px-4 py-2.5 rounded-xl input-field text-sm bg-white">
                                    <option value="">İlçe Seçiniz</option>
                                    <?php $__currentLoopData = $ilce_mudurlukleri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ilce->id); ?>" data-il="<?php echo e($ilce->il_mudurluk_id); ?>" <?php echo e(old('ilce_mudurluk_id') == $ilce->id ? 'selected' : ''); ?>><?php echo e($ilce->ad); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- 4. Birim -->
                            <div class="md:col-span-2">
                                <label class="block text-xs font-semibold text-gray-700 mb-1.5">Birim <span class="text-red-500">*</span></label>
                                <select name="birim" id="birim_select" class="w-full px-4 py-2.5 rounded-xl input-field text-sm bg-white">
                                    <option value="">Birim Seçiniz</option>
                                    <option value="spor" <?php echo e(old('birim') == 'spor' ? 'selected' : ''); ?>>Spor Birimi</option>
                                    <option value="muhasebe" <?php echo e(old('birim') == 'muhasebe' ? 'selected' : ''); ?>>Muhasebe Birimi</option>
                                    <option value="tahakkuk" <?php echo e(old('birim') == 'tahakkuk' ? 'selected' : ''); ?>>Tahakkuk Birimi</option>
                                    <option value="personel" <?php echo e(old('birim') == 'personel' ? 'selected' : ''); ?>>Personel Birimi</option>
                                </select>
                            </div>
                        </div>

                        <!-- 5. Email/Telefon Seçimi -->
                        <div class="flex gap-2 mb-4">
                            <button type="button" onclick="switchGirisTuru('email')" id="tab-email" class="tab-btn active flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2">
                                <i class="fas fa-envelope"></i>
                                <span>E-Posta</span>
                            </button>
                            <button type="button" onclick="switchGirisTuru('telefon')" id="tab-telefon" class="tab-btn flex-1 py-3 rounded-xl text-sm font-bold text-gray-600 flex items-center justify-center gap-2">
                                <i class="fas fa-mobile-screen"></i>
                                <span>Telefon</span>
                            </button>
                        </div>

                        <!-- 6. Email Input -->
                        <div id="email_field" class="mb-3">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5">E-posta Adresi</label>
                            <div class="relative">
                                <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                <input type="email" name="email" id="email_input" class="w-full pl-11 pr-4 py-2.5 rounded-xl input-field text-sm" placeholder="ornek@email.com" value="<?php echo e(old('email')); ?>" required>
                            </div>
                        </div>

                        <!-- 6. Telefon Input -->
                        <div id="telefon_field" class="mb-3 hidden">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5">Cep Telefonu</label>
                            <div class="relative">
                                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-xs">+90</span>
                                <input type="tel" name="telefon" id="telefon_input" class="w-full pl-12 pr-4 py-2.5 rounded-xl input-field text-sm" placeholder="532 123 45 67" maxlength="10" value="<?php echo e(old('telefon')); ?>">
                            </div>
                            <p class="text-xs text-gray-500 mt-1 ml-1">Başında 0 olmadan giriniz</p>
                        </div>

                        <!-- 7. Şifre -->
                        <div class="mb-4">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5">Şifre</label>
                            <div class="relative">
                                <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                <input type="password" name="sifre" id="sifreInput" class="w-full pl-11 pr-12 py-2.5 rounded-xl input-field text-sm" placeholder="Şifreniz" required value="<?php echo e(old('sifre', 'Tahakkuk2024!')); ?>">
                                <button type="button" onclick="togglePassword()" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors">
                                    <i class="fas fa-eye" id="eyeIcon"></i>
                                </button>
                            </div>
                            <p class="text-xs text-blue-600 mt-1.5 font-semibold flex items-center gap-1">
                                <i class="fas fa-lock"></i>
                                Sabit Şifre: Tahakkuk2024!
                            </p>
                        </div>

                        <!-- Alt Satır -->
                        <div class="flex items-center justify-between mb-5">
                            <label class="flex items-center cursor-pointer select-none">
                                <input type="checkbox" name="remember" class="w-4 h-4 text-primary-600 rounded border-gray-300 focus:ring-primary-500" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <span class="ml-2 text-xs text-gray-600 font-medium">Beni hatırla</span>
                            </label>
                            <a href="<?php echo e(route('sifre.sifirlama')); ?>" class="text-xs text-primary-600 hover:text-primary-700 font-semibold transition-colors">Şifremi unuttum?</a>
                        </div>

                        <!-- GİRİŞ BUTONU -->
                        <button type="submit" class="giris-btn w-full py-3.5 rounded-xl text-white font-bold text-base flex items-center justify-center gap-2">
                            <i class="fas fa-right-to-bracket"></i>
                            <span>Giriş Yap</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toast Notification System
        const Toast = {
            container: null,

            init() {
                if (!this.container) {
                    this.container = document.getElementById('toastContainer');
                }
            },

            show(message, type = 'info', duration = 5000) {
                this.init();

                const icons = {
                    success: 'fa-check-circle',
                    error: 'fa-exclamation-circle',
                    warning: 'fa-exclamation-triangle',
                    info: 'fa-info-circle'
                };

                const titles = {
                    success: 'Başarılı',
                    error: 'Hata',
                    warning: 'Uyarı',
                    info: 'Bilgi'
                };

                const toast = document.createElement('div');
                toast.className = `toast toast-${type}`;
                toast.innerHTML = `
                    <div class="toast-icon">
                        <i class="fas ${icons[type]}"></i>
                    </div>
                    <div class="toast-content">
                        <div class="toast-title">${titles[type]}</div>
                        <div class="toast-message">${message}</div>
                    </div>
                    <div class="toast-close" onclick="Toast.dismiss(this.parentElement)">
                        <i class="fas fa-times"></i>
                    </div>
                    <div class="toast-progress" style="width: 100%;"></div>
                `;

                this.container.appendChild(toast);

                requestAnimationFrame(() => {
                    toast.classList.add('show');
                });

                const progress = toast.querySelector('.toast-progress');
                progress.style.transition = `width ${duration}ms linear`;
                requestAnimationFrame(() => {
                    progress.style.width = '0%';
                });

                const timeout = setTimeout(() => {
                    this.dismiss(toast);
                }, duration);

                toast.addEventListener('mouseenter', () => {
                    clearTimeout(timeout);
                    progress.style.transition = 'none';
                });

                toast.addEventListener('mouseleave', () => {
                    progress.style.transition = `width ${duration}ms linear`;
                    progress.style.width = '0%';
                    setTimeout(() => {
                        this.dismiss(toast);
                    }, duration);
                });
            },

            dismiss(toast) {
                toast.classList.remove('show');
                toast.classList.add('hide');

                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.parentElement.removeChild(toast);
                    }
                }, 400);
            },

            success(message, duration = 5000) {
                this.show(message, 'success', duration);
            },

            error(message, duration = 8000) {
                this.show(message, 'error', duration);
            },

            warning(message, duration = 6000) {
                this.show(message, 'warning', duration);
            },

            info(message, duration = 5000) {
                this.show(message, 'info', duration);
            }
        };

        const il_mudurlukleri = <?php echo json_encode($il_mudurlukleri, 15, 512) ?>;
        const ilce_mudurlukleri = <?php echo json_encode($ilce_mudurlukleri, 15, 512) ?>;

        function selectRole(role, element) {
            document.querySelectorAll('.role-btn, .mobile-tabs .tab-btn').forEach(btn => {
                btn.classList.remove('active');
                const icon = btn.querySelector('.check-icon');
                if (icon) {
                    icon.classList.remove('text-primary-500');
                    icon.classList.add('text-gray-300');
                }
            });

            element.classList.add('active');
            const activeIcon = element.querySelector('.check-icon');
            if (activeIcon) {
                activeIcon.classList.remove('text-gray-300');
                activeIcon.classList.add('text-primary-500');
            }

            document.getElementById('kullanici_turu').value = role;

            const il = document.getElementById('il_secimi');
            const ilce = document.getElementById('ilce_secimi');

            if (il) il.style.display = 'none';
            if (ilce) ilce.style.display = 'none';

            if (role === 'il_muduru') {
                if (il) il.style.display = 'block';
            } else if (role === 'ilce_muduru') {
                if (il) il.style.display = 'block';
                if (ilce) ilce.style.display = 'block';
            }
        }

        function bakanlikDegisti() {
            const bakanlikId = document.getElementById('bakanlik_select').value;
            const ilSelect = document.getElementById('il_select');

            if (ilSelect) {
                const currentIl = ilSelect.value;
                ilSelect.innerHTML = '<option value="">İl Seçiniz</option>';

                if (bakanlikId && il_mudurlukleri) {
                    const filtreli = il_mudurlukleri.filter(i => i.bakanlik_id == bakanlikId);
                    filtreli.forEach(i => {
                        const selected = (i.id == currentIl) ? 'selected' : '';
                        ilSelect.innerHTML += '<option value="' + i.id + '" ' + selected + '>' + i.ad + '</option>';
                    });
                }
            }

            ilDegisti();
        }

        function ilDegisti() {
            const ilId = document.getElementById('il_select').value;
            const ilceSelect = document.getElementById('ilce_select');

            if (ilceSelect) {
                const currentIlce = ilceSelect.value;
                ilceSelect.innerHTML = '<option value="">İlçe Seçiniz</option>';

                if (ilId && ilce_mudurlukleri) {
                    const filtreli = ilce_mudurlukleri.filter(i => i.il_mudurluk_id == ilId);
                    filtreli.forEach(i => {
                        const selected = (i.id == currentIlce) ? 'selected' : '';
                        ilceSelect.innerHTML += '<option value="' + i.id + '" ' + selected + '>' + i.ad + '</option>';
                    });
                }
            }
        }

        function switchGirisTuru(turu) {
            const emailTab = document.getElementById('tab-email');
            const telefonTab = document.getElementById('tab-telefon');
            const emailField = document.getElementById('email_field');
            const telefonField = document.getElementById('telefon_field');
            const girisTuru = document.getElementById('giris_turu');

            if (!emailTab || !telefonTab) return;

            if (turu === 'email') {
                emailTab.classList.add('active');
                telefonTab.classList.remove('active');
                if (emailField) emailField.classList.remove('hidden');
                if (telefonField) telefonField.classList.add('hidden');
                const emailInput = document.getElementById('email_input');
                const telefonInput = document.getElementById('telefon_input');
                if (emailInput) emailInput.required = true;
                if (telefonInput) telefonInput.required = false;
            } else {
                telefonTab.classList.add('active');
                emailTab.classList.remove('active');
                if (telefonField) telefonField.classList.remove('hidden');
                if (emailField) emailField.classList.add('hidden');
                const emailInput = document.getElementById('email_input');
                const telefonInput = document.getElementById('telefon_input');
                if (telefonInput) telefonInput.required = true;
                if (emailInput) emailInput.required = false;
            }

            if (girisTuru) girisTuru.value = turu;
        }

        function togglePassword() {
            const input = document.getElementById('sifreInput');
            const icon = document.getElementById('eyeIcon');
            if (input && icon) {
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            }
        }

        const telefonInput = document.getElementById('telefon_input');
        if (telefonInput) {
            telefonInput.addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 10) value = value.slice(0, 10);
                e.target.value = value;
            });
        }

        // Session Messages as Toast
        window.addEventListener('load', function() {
            <?php if(session('success')): ?>
                Toast.success('<?php echo e(session('success')); ?>', 5000);
            <?php endif; ?>

            <?php if(session('error')): ?>
                Toast.error('<?php echo e(session('error')); ?>', 8000);
            <?php endif; ?>
        });

        window.addEventListener('load', function() {
            bakanlikDegisti();
        });
    </script>
</body>
</html><?php /**PATH /home/tahakkuk/domains/tahakkuk.online/resources/views/auth/login.blade.php ENDPATH**/ ?>