<?php
header('Content-Type: text/html; charset=utf-8');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use Illuminate\Contracts\Console\Kernel;

require __DIR__ . '/../vendor/autoload.php';

$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Kernel::class);
$kernel->bootstrap();

$commandOutput = '';
$lastCommand = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['command'])) {
    $lastCommand = trim($_POST['command']);

    if (!empty($lastCommand)) {
        $commands = explode("\n", $lastCommand);
        $totalOutput = '';

        foreach ($commands as $cmd) {
            $cmd = trim($cmd);
            if (empty($cmd)) continue;

            $totalOutput .= "\n" . str_repeat('=', 60) . "\n";
            $totalOutput .= "> " . $cmd . "\n";
            $totalOutput .= str_repeat('=', 60) . "\n\n";

            try {
                ob_start();
                $kernel->call($cmd);
                $totalOutput .= $kernel->output();
                ob_end_clean();
            } catch (Throwable $e) {
                $totalOutput .= "ERROR:\n" . $e->getMessage() . "\n";
            }

            $totalOutput .= "\n";
        }

        $commandOutput = $totalOutput;
    }
}

$phpVersion = phpversion();
$laravelVersion = $app->version();
$dbConnection = config('database.default');
$dbHost = config('database.connections.mysql.host');
$dbDatabase = config('database.connections.mysql.database');
$env = config('app.env');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAHAKKUK Dev Tool v4.1</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); min-height: 100vh; color: #e2e8f0; }
        .sidebar { position: fixed; left: 0; top: 0; width: 400px; height: 100vh; background: rgba(30, 41, 59, 0.95); backdrop-filter: blur(10px); border-right: 1px solid rgba(255,255,255,0.1); overflow-y: auto; z-index: 10; }
        .main-content { margin-left: 400px; min-height: 100vh; padding: 20px; }
        .sidebar-header { padding: 20px; background: linear-gradient(135deg, #1e293b, #0f172a); border-bottom: 1px solid rgba(255,255,255,0.1); position: sticky; top: 0; z-index: 10; }
        .system-info { padding: 16px; background: rgba(15, 23, 42, 0.6); border-bottom: 1px solid rgba(255,255,255,0.05); }
        .info-row { display: flex; justify-content: space-between; padding: 4px 0; font-size: 0.75rem; color: #94a3b8; }
        .info-row span:last-child { color: #a5f3fc; font-weight: 500; }
        .command-group { padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .command-group h3 { font-size: 0.7rem; text-transform: uppercase; color: #64748b; margin-bottom: 12px; letter-spacing: 1px; }
        .command-buttons { display: flex; flex-wrap: wrap; gap: 6px; }
        .cmd-btn { background: rgba(51, 65, 85, 0.6); border: 1px solid rgba(255,255,255,0.08); padding: 6px 12px; border-radius: 8px; font-size: 0.7rem; font-family: monospace; color: #cbd5e1; cursor: pointer; transition: all 0.2s; }
        .cmd-btn:hover { background: #3b82f6; color: white; transform: translateY(-1px); }
        .cmd-btn.danger:hover { background: #ef4444; }
        .cmd-btn.warning:hover { background: #f59e0b; }
        .cmd-btn.success:hover { background: #10b981; }
        .terminal-container { background: rgba(30, 41, 59, 0.8); backdrop-filter: blur(10px); border-radius: 24px; border: 1px solid rgba(255,255,255,0.1); overflow: hidden; max-width: 1200px; margin: 0 auto; }
        .terminal-header { background: #1e293b; padding: 12px 20px; display: flex; align-items: center; gap: 8px; border-bottom: 1px solid #334155; }
        .terminal-dot { width: 12px; height: 12px; border-radius: 50%; }
        .terminal-dot.red { background: #ef4444; }
        .terminal-dot.yellow { background: #f59e0b; }
        .terminal-dot.green { background: #10b981; }
        .terminal-title { font-size: 0.75rem; color: #64748b; margin-left: 8px; }
        .terminal-body { padding: 24px; }
        .example-hint { background: rgba(51,65,85,0.4); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; font-size: 0.75rem; border-left: 3px solid #3b82f6; }
        .example-hint code { background: #1e293b; padding: 2px 6px; border-radius: 6px; color: #a5f3fc; }
        textarea { width: 100%; height: 250px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; padding: 12px 16px; color: #a5f3fc; font-family: 'Monaco', monospace; font-size: 0.85rem; resize: vertical; outline: none; }
        textarea:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,0.2); }
        .button-group { display: flex; gap: 12px; margin-top: 16px; }
        button { padding: 10px 24px; border-radius: 12px; font-size: 0.85rem; font-weight: 500; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; gap: 8px; border: none; }
        .run-btn button { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; }
        .clear-btn button { background: rgba(51,65,85,0.6); color: #cbd5e1; }
        .output { margin-top: 20px; padding-top: 20px; border-top: 1px solid #1e293b; }
        .output-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .output-label { font-size: 0.7rem; text-transform: uppercase; color: #64748b; }
        .copy-btn button { background: rgba(16,185,129,0.2); border: 1px solid rgba(16,185,129,0.3); padding: 6px 12px; font-size: 0.7rem; color: #10b981; }
        .copy-btn button:hover { background: #10b981; color: white; }
        .output pre { background: #0f172a; padding: 16px; border-radius: 12px; font-family: monospace; font-size: 0.75rem; line-height: 1.5; color: #94a3b8; white-space: pre-wrap; max-height: 400px; overflow-y: auto; }
        .footer { text-align: center; margin-top: 30px; font-size: 0.7rem; color: #475569; }
        .toast { position: fixed; bottom: 20px; right: 20px; background: #10b981; color: white; padding: 12px 24px; border-radius: 12px; font-size: 0.85rem; z-index: 1000; animation: fadeOut 2s forwards; }
        @keyframes fadeOut { 0% { opacity: 1; transform: translateY(0); } 70% { opacity: 1; } 100% { opacity: 0; transform: translateY(-20px); visibility: hidden; } }
        @media (max-width: 900px) { .sidebar { width: 280px; } .main-content { margin-left: 280px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h3 style="color:white;">🚀 TAHAKKUK Dev Tool v4.1</h3>
            <p style="font-size:0.7rem; color:#64748b;">Paylasimli Host - Terminal Yok</p>
        </div>

        <div class="system-info">
            <div class="info-row"><span>PHP</span><span><?php echo $phpVersion; ?></span></div>
            <div class="info-row"><span>Laravel</span><span><?php echo $laravelVersion; ?></span></div>
            <div class="info-row"><span>Database</span><span><?php echo $dbConnection; ?></span></div>
            <div class="info-row"><span>Host</span><span><?php echo $dbHost; ?></span></div>
            <div class="info-row"><span>DB</span><span><?php echo $dbDatabase; ?></span></div>
            <div class="info-row"><span>Env</span><span><?php echo $env; ?></span></div>
        </div>

        <div class="command-group"><h3>🗑️ CACHE & CLEAR</h3>
            <div class="command-buttons">
                <button class="cmd-btn" onclick="addCommand('optimize:clear')">optimize:clear</button>
                <button class="cmd-btn" onclick="addCommand('cache:clear')">cache:clear</button>
                <button class="cmd-btn" onclick="addCommand('config:clear')">config:clear</button>
                <button class="cmd-btn" onclick="addCommand('view:clear')">view:clear</button>
                <button class="cmd-btn" onclick="addCommand('route:clear')">route:clear</button>
            </div>
        </div>

        <div class="command-group"><h3>🛣️ ROUTE</h3>
            <div class="command-buttons">
                <button class="cmd-btn" onclick="addCommand('route:list')">route:list</button>
            </div>
        </div>

        <div class="command-group"><h3>💾 DATABASE - MIGRATION</h3>
            <div class="command-buttons">
                <button class="cmd-btn success" onclick="addCommand('migrate')">migrate</button>
                <button class="cmd-btn success" onclick="addCommand('migrate --force')">migrate --force</button>
                <button class="cmd-btn warning" onclick="addCommand('migrate:fresh')">migrate:fresh</button>
                <button class="cmd-btn warning" onclick="addCommand('migrate:fresh --force')">migrate:fresh --force</button>
                <button class="cmd-btn" onclick="addCommand('migrate:status')">migrate:status</button>
                <button class="cmd-btn" onclick="addCommand('migrate:rollback')">migrate:rollback</button>
            </div>
        </div>

        <div class="command-group"><h3>🌱 DATABASE - SEED</h3>
            <div class="command-buttons">
                <button class="cmd-btn success" onclick="addCommand('db:seed')">db:seed</button>
                <button class="cmd-btn success" onclick="addCommand('db:seed --force')">db:seed --force</button>
                <button class="cmd-btn" onclick="addCommand('db:seed --class=DatabaseSeeder')">db:seed DatabaseSeeder</button>
            </div>
        </div>

        <div class="command-group"><h3>🔧 KURULUM KOMUTLARI</h3>
            <div class="command-buttons">
                <button class="cmd-btn success" onclick="addCommand('migrate --force\ndb:seed --force')">🚀 TAM KURULUM</button>
                <button class="cmd-btn warning" onclick="addCommand('migrate:fresh --force\ndb:seed --force')">🔄 SIFIRDAN KUR</button>
                <button class="cmd-btn" onclick="addCommand('config:cache\nroute:cache\nview:cache')">⚡ CACHE OLUSTUR</button>
            </div>
        </div>

        <div class="command-group"><h3>ℹ️ INFO</h3>
            <div class="command-buttons">
                <button class="cmd-btn" onclick="addCommand('about')">about</button>
                <button class="cmd-btn" onclick="addCommand('env')">env</button>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="terminal-container">
            <div class="terminal-header">
                <div class="terminal-dot red"></div>
                <div class="terminal-dot yellow"></div>
                <div class="terminal-dot green"></div>
                <span class="terminal-title">multi-command@tahakkuk:~</span>
            </div>

            <div class="terminal-body">
                <div class="example-hint">
                    💡 <strong>Paylasimli Host Modu:</strong> Terminal yok, composer yok.<br>
                    <strong>Tum islemler buradan yapilir.</strong><br><br>
                    <strong>Ornek:</strong><br>
                    <code>migrate --force</code><br>
                    <code>db:seed --force</code><br>
                    <code>optimize:clear</code>
                </div>

                <form method="POST" id="terminalForm">
                    <textarea name="command" id="commandInput" placeholder="Her satira bir komut yazin..."><?php echo htmlspecialchars($lastCommand, ENT_QUOTES, 'UTF-8') ?></textarea>
                    <div class="button-group">
                        <div class="clear-btn">
                            <button type="button" onclick="clearTextarea()">🗑️ Temizle</button>
                        </div>
                        <div class="run-btn">
                            <button type="submit">▶ Calistir</button>
                        </div>
                    </div>
                </form>

                <?php if (!empty($commandOutput)): ?>
                <div class="output">
                    <div class="output-header">
                        <div class="output-label">📟 CIKTI</div>
                        <div class="copy-btn"><button onclick="copyOutput()">📋 Kopyala</button></div>
                    </div>
                    <pre id="outputContent"><?php echo htmlspecialchars($commandOutput, ENT_QUOTES, 'UTF-8') ?></pre>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            TAHAKKUK Dev Tool v4.1 | Paylasimli Host Uyumlu | © <?php echo date('Y') ?> 
        </div>
    </div>

    <script>
        function addCommand(cmd) {
            const textarea = document.getElementById('commandInput');
            const current = textarea.value.trim();
            textarea.value = current ? current + '\n' + cmd : cmd;
            textarea.focus();
            textarea.scrollTop = textarea.scrollHeight;
        }

        function clearTextarea() {
            document.getElementById('commandInput').value = '';
            document.getElementById('commandInput').focus();
        }

        function copyOutput() {
            const output = document.getElementById('outputContent');
            const text = output.innerText;

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(() => {
                    showToast('✅ Kopyalandi!');
                }).catch(() => {
                    fallbackCopy(text);
                });
            } else {
                fallbackCopy(text);
            }
        }

        function fallbackCopy(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast('✅ Kopyalandi!');
        }

        function showToast(msg) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 2000);
        }

        document.getElementById('commandInput')?.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('terminalForm').submit();
            }
        });
    </script>
</body>
</html>
