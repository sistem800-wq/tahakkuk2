<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function index()
    {
        $data = [
            'title' => 'Spor2023 Test Sayfası',
            'message' => 'Blade ve Laravel çalışıyor!',
            'tarih' => now()->format('d.m.Y H:i:s'),
            'kullanicilar' => [
                ['ad' => 'Ahmet', 'rol' => 'İl Müdürü'],
                ['ad' => 'Mehmet', 'rol' => 'İlçe Müdürü'],
                ['ad' => 'Ayşe', 'rol' => 'Personel'],
            ]
        ];

        return view('test', $data);
    }
}