<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IlDashboardController extends Controller
{
    public function index()
    {
        return view('dashboard.il');
    }
}
