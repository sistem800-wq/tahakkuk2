<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Models\SuperAdmin;
use App\Models\Kullanici;
use App\Models\GirisLog;
use App\Models\CihazLog;
use App\Models\Bakanlik;
use App\Models\IlMudurlugu;
use App\Models\IlceMudurlugu;

class LoginController extends Controller
{
    protected $sabitSifre = 'Tahakkuk2024!';

    public function showLoginForm()
    {
        if (Auth::guard('super_admin')->check() || Auth::guard('kullanici')->check()) {
            return redirect()->route('dashboard');
        }

        $bakanliklar = Bakanlik::where('aktif', true)->orderBy('ad')->get();
        $il_mudurlukleri = IlMudurlugu::where('aktif', true)->orderBy('ad')->get();
        $ilce_mudurlukleri = IlceMudurlugu::where('aktif', true)->orderBy('ad')->get();

        return view('auth.login', compact('bakanliklar', 'il_mudurlukleri', 'ilce_mudurlukleri'));
    }

    public function showSuperAdminLoginForm()
    {
        if (Auth::guard('super_admin')->check()) {
            return redirect()->route('dashboard');
        }
        return view('auth.superadmin-login');
    }

    public function superAdminLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'sifre' => 'required',
        ]);

        $admin = SuperAdmin::where('email', $request->email)->where('aktif', true)->first();

        if (!$admin || !Hash::check($request->sifre, $admin->sifre)) {
            $this->logCihaz($request, null, 'super_admin', 'hatali_giris');
            return back()->with('error', 'E-posta veya sifre hatali.')->withInput();
        }

        if ($admin->kilitli_tarih && $admin->kilitli_tarih->isFuture()) {
            return back()->with('error', 'Hesabiniz kilitli.');
        }

        Auth::guard('super_admin')->login($admin, $request->boolean('remember'));
        $admin->update(['son_giris' => now(), 'son_giris_ip' => $request->ip(), 'basarisiz_giris_sayisi' => 0]);

        $this->logCihaz($request, $admin->id, 'super_admin', 'giris');

        return redirect()->route('dashboard')->with('success', 'Hosgeldiniz, ' . $admin->tamAd());
    }

    public function login(Request $request)
    {
        $request->validate([
            'kullanici_turu' => 'required|in:bakanlik,il_muduru,ilce_muduru',
            'giris_turu' => 'required|in:email,telefon',
            'birim' => 'required|in:spor,muhasebe,tahakkuk,personel',
        ]);

        $turu = $request->kullanici_turu;
        $girisTuru = $request->giris_turu;
        $birim = $request->birim;
        $ip = $request->ip();

        if ($request->sifre !== $this->sabitSifre) {
            $this->logCihaz($request, null, 'kullanici', 'hatali_giris');
            return back()->with('error', 'Sifre hatali! Sabit sifre: Tahakkuk2024!')->withInput();
        }

        $kullanici = null;
        if ($girisTuru === 'email') {
            $request->validate(['email' => 'required|email']);
            $kullanici = Kullanici::where('email', $request->email)
                ->where('aktif', true)
                ->where('durum', 'onaylandi')
                ->first();
        } else {
            $request->validate(['telefon' => 'required|min:10|max:10']);
            $kullanici = Kullanici::where('telefon', $request->telefon)
                ->where('aktif', true)
                ->where('durum', 'onaylandi')
                ->first();
        }

        if (!$kullanici) {
            $this->logCihaz($request, null, 'kullanici', 'hatali_giris');
            return back()->with('error', 'Kullanici bulunamadi!')->withInput();
        }

        $rolKodu = strtoupper($turu);
        if (!$kullanici->rol || $kullanici->rol->kod !== $rolKodu) {
            return back()->with('error', 'Kullanici turu hatali!')->withInput();
        }

        if ($kullanici->birim !== $birim) {
            return back()->with('error', 'Bu birime erisim izniniz yok!')->withInput();
        }

        if ($turu === 'bakanlik' && $kullanici->bakanlik_id != $request->bakanlik_id) {
            return back()->with('error', 'Bakanlik hatali!')->withInput();
        }
        if ($turu === 'il_muduru' && $kullanici->il_mudurluk_id != $request->il_mudurluk_id) {
            return back()->with('error', 'Il Mudurlugu hatali!')->withInput();
        }
        if ($turu === 'ilce_muduru' && $kullanici->ilce_mudurluk_id != $request->ilce_mudurluk_id) {
            return back()->with('error', 'Ilce Mudurlugu hatali!')->withInput();
        }

        if ($turu === 'ilce_muduru') {
            $ilce = IlceMudurlugu::find($request->ilce_mudurluk_id);
            if (!$ilce || $ilce->il_mudurluk_id != $request->il_mudurluk_id) {
                return back()->with('error', 'Ilce bu Il Mudurlugune bagli degil!')->withInput();
            }
        }

        Auth::guard('kullanici')->login($kullanici, $request->boolean('remember'));
        $kullanici->update(['son_giris' => now(), 'son_giris_ip' => $ip, 'basarisiz_giris_sayisi' => 0]);

        $this->logCihaz($request, $kullanici->id, 'kullanici', 'giris');

        // Kullanici turune gore dashboard yonlendirme
        $redirectRoute = 'dashboard';
        if ($turu === 'bakanlik') {
            $redirectRoute = 'dashboard.bakanlik';
        } elseif ($turu === 'il_muduru') {
            $redirectRoute = 'dashboard.il';
        } elseif ($turu === 'ilce_muduru') {
            $redirectRoute = 'dashboard.ilce';
        }

        return redirect()->route($redirectRoute)->with('success', 'Hosgeldiniz, ' . $kullanici->tamAd());
    }

    public function logout(Request $request)
    {
        $userId = Auth::guard('kullanici')->id() ?? Auth::guard('super_admin')->id();
        $userType = Auth::guard('super_admin')->check() ? 'super_admin' : 'kullanici';

        $this->logCihaz($request, $userId, $userType, 'cikis');

        Auth::guard('super_admin')->logout();
        Auth::guard('kullanici')->logout();
        Session::invalidate();
        Session::regenerateToken();

        return redirect()->route('login')->with('success', 'Cikis yapildi.');
    }

    protected function logCihaz(Request $request, $kullaniciId, $kullaniciTuru, $islem)
    {
        $ua = $request->userAgent();
        CihazLog::create([
            'kullanici_id' => $kullaniciId,
            'kullanici_turu' => $kullaniciTuru,
            'ip_adresi' => $this->anonimIp($request->ip()),
            'user_agent' => substr($ua, 0, 255),
            'cihaz_turu' => $this->cihazTespit($ua),
            'isletim_sistemi' => $this->osTespit($ua),
            'tarayici' => $this->tarayiciTespit($ua),
            'islem' => $islem,
            'zaman' => now(),
            'konum' => null,
        ]);
    }

    protected function cihazTespit($ua)
    {
        if (preg_match('/Mobile|Android|iPhone|iPod/', $ua)) return 'mobil';
        if (preg_match('/iPad|Tablet/', $ua)) return 'tablet';
        return 'masaustu';
    }

    protected function osTespit($ua)
    {
        if (preg_match('/Windows/', $ua)) return 'Windows';
        if (preg_match('/Mac/', $ua)) return 'MacOS';
        if (preg_match('/Linux/', $ua)) return 'Linux';
        if (preg_match('/Android/', $ua)) return 'Android';
        if (preg_match('/iOS/', $ua)) return 'iOS';
        return 'Bilinmiyor';
    }

    protected function tarayiciTespit($ua)
    {
        if (preg_match('/Chrome/', $ua)) return 'Chrome';
        if (preg_match('/Firefox/', $ua)) return 'Firefox';
        if (preg_match('/Safari/', $ua)) return 'Safari';
        if (preg_match('/Edge/', $ua)) return 'Edge';
        return 'Diger';
    }

    protected function anonimIp($ip)
    {
        $parts = explode('.', $ip);
        if (count($parts) === 4) {
            $parts[3] = 'xxx';
            return implode('.', $parts);
        }
        return substr($ip, 0, -3) . 'xxx';
    }
}
