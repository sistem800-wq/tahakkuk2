<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Models\Kullanici;
use App\Models\SuperAdmin;
use App\Models\SifreSifirlama;
use Carbon\Carbon;

class SifreSifirlamaController extends Controller
{
    public function showSifreSifirlamaForm()
    {
        return view('auth.sifre-sifirlama');
    }

    public function sendToken(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $email = $request->email;

        // Kullanici turunu belirle
        $kullaniciTuru = 'kullanici';
        $kullanici = Kullanici::where('email', $email)->where('aktif', true)->first();
        if (!$kullanici) {
            $admin = SuperAdmin::where('email', $email)->where('aktif', true)->first();
            if ($admin) {
                $kullaniciTuru = 'super_admin';
            }
        }

        if (!$kullanici && !isset($admin)) {
            return back()->with('error', 'Bu email adresi ile kayitli kullanici bulunamadi!')->withInput();
        }

        // Token olustur
        $token = Str::random(64);

        // Eski tokenlari temizle
        SifreSifirlama::where('email', $email)->where('kullanildi', false)->update(['kullanildi' => true]);

        // Yeni token kaydet
        SifreSifirlama::create([
            'email' => $email,
            'token' => $token,
            'kullanici_turu' => $kullaniciTuru,
            'olusturulma_zamani' => now(),
            'son_kullanma_zamani' => now()->addHours(1),
            'kullanildi' => false,
        ]);

        $resetLink = url('/sifre-sifirlama/' . $token);
        $kod = substr($token, 0, 6);

        // MAIL GONDERIMI - COKLU DENEME
        $mailSent = false;
        $mailError = '';

        // Deneme 1: SMTP TLS
        try {
            config(['mail.mailers.smtp.verify_peer' => false]);
            config(['mail.mailers.smtp.verify_peer_name' => false]);
            config(['mail.mailers.smtp.allow_self_signed' => true]);

            Mail::send('emails.sifre-sifirlama', [
                'link' => $resetLink,
                'kod' => $kod,
                'email' => $email
            ], function($message) use ($email) {
                $message->to($email)
                        ->from('resetsifre@tahakkuk.online', 'Tahakkuk.Online')
                        ->subject('Sifre Sifirlama - Tahakkuk.Online');
            });

            $mailSent = true;
        } catch (\Exception $e) {
            $mailError = $e->getMessage();
            \Log::warning('SMTP TLS hatasi: ' . $mailError);
        }

        // Deneme 2: Log modu (test icin)
        if (!$mailSent) {
            try {
                // Log dosyasina yaz
                $logContent = "\n=== SIFRE SIFIRLAMA ===\n";
                $logContent .= "Tarih: " . now() . "\n";
                $logContent .= "Email: " . $email . "\n";
                $logContent .= "Kod: " . $kod . "\n";
                $logContent .= "Link: " . $resetLink . "\n";
                $logContent .= "=====================\n";

                file_put_contents(storage_path('logs/mail_debug.log'), $logContent, FILE_APPEND);

                \Log::info('Email log modunda kaydedildi: ' . $email);
            } catch (\Exception $e2) {
                \Log::error('Log hatasi: ' . $e2->getMessage());
            }
        }

        // Kullaniciya mesaj
        if ($mailSent) {
            return redirect()->route('sifre.sifirlama')
                ->with('success', 'Sifre sifirlama linki email adresinize gonderildi! Lutfen email kutunuzu kontrol edin.');
        } else {
            // Debug modunda tokeni goster (guvenlik icin productionda kaldir)
            return redirect()->route('sifre.sifirlama')
                ->with('success', 'Sifre sifirlama istegi alindi! Email servisi gecici olarak kullanilamiyor. Lutfen sistem yoneticisi ile iletisime gecin.')
                ->with('token', $token); // Debug - productionda kaldir
        }
    }

    public function sendSmsToken(Request $request)
    {
        $request->validate([
            'telefon' => 'required|min:10|max:10',
        ]);

        $telefon = $request->telefon;
        $kullanici = Kullanici::where('telefon', $telefon)->where('aktif', true)->first();

        if (!$kullanici) {
            return back()->with('error', 'Bu telefon numarasi ile kayitli kullanici bulunamadi!')->withInput();
        }

        $kod = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        SifreSifirlama::where('email', $kullanici->email)->where('kullanildi', false)->update(['kullanildi' => true]);

        SifreSifirlama::create([
            'email' => $kullanici->email,
            'token' => $kod,
            'kullanici_turu' => 'kullanici',
            'olusturulma_zamani' => now(),
            'son_kullanma_zamani' => now()->addMinutes(15),
            'kullanildi' => false,
        ]);

        \Log::info('SMS kodu: ' . $kod . ' - Telefon: ' . $telefon);

        return redirect()->route('sifre.sifirlama')
            ->with('success', 'SMS kodu telefonunuza gonderildi!');
    }

    public function showYeniSifreForm($token)
    {
        $sifreSifirlama = SifreSifirlama::where('token', $token)
            ->where('kullanildi', false)
            ->where('son_kullanma_zamani', '>', now())
            ->first();

        if (!$sifreSifirlama) {
            return redirect()->route('sifre.sifirlama')->with('error', 'Gecersiz veya suresi dolmus token!');
        }

        return view('auth.yeni-sifre', compact('token'));
    }

    public function showYeniSifreFormByCode(Request $request)
    {
        $kod = $request->query('kod');

        if (!$kod || strlen($kod) !== 6 || !ctype_digit($kod)) {
            return redirect()->route('sifre.sifirlama')->with('error', 'Gecersiz kod formati! 6 haneli rakam giriniz.');
        }

        $sifreSifirlama = SifreSifirlama::where('token', $kod)
            ->where('kullanildi', false)
            ->where('son_kullanma_zamani', '>', now())
            ->first();

        if (!$sifreSifirlama) {
            return redirect()->route('sifre.sifirlama')->with('error', 'Gecersiz veya suresi dolmus kod!');
        }

        return view('auth.yeni-sifre', ['token' => $kod]);
    }

    public function updateSifre(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'sifre' => 'required|min:6|confirmed',
        ]);

        $sifreSifirlama = SifreSifirlama::where('token', $request->token)
            ->where('kullanildi', false)
            ->where('son_kullanma_zamani', '>', now())
            ->first();

        if (!$sifreSifirlama) {
            return redirect()->route('sifre.sifirlama')->with('error', 'Gecersiz veya suresi dolmus token!');
        }

        $email = $sifreSifirlama->email;

        $kullanici = Kullanici::where('email', $email)->first();
        if ($kullanici) {
            $kullanici->update(['sifre' => Hash::make($request->sifre)]);
        }

        $admin = SuperAdmin::where('email', $email)->first();
        if ($admin) {
            $admin->update(['sifre' => Hash::make($request->sifre)]);
        }

        $sifreSifirlama->update(['kullanildi' => true]);

        return redirect()->route('login')->with('success', 'Sifreniz basariyla guncellendi! Yeni sifreniz ile giris yapabilirsiniz.');
    }
}
