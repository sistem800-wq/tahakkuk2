<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IlceDashboardController extends Controller
{
    public function index()
    {
        return view('dashboard.ilce');
    }
}
