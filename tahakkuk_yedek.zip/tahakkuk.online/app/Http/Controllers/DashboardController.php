<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        // Önce super admin kontrolü
        if (Auth::guard('super_admin')->check()) {
            return redirect()->route('dashboard.bakanlik');
        }

        $user = Auth::guard('kullanici')->user();

        if (!$user) {
            return redirect()->route('login');
        }

        // Kullanici turune gore yonlendirme
        if ($user->rol && $user->rol->kod === 'BAKANLIK') {
            return redirect()->route('dashboard.bakanlik');
        } elseif ($user->rol && $user->rol->kod === 'IL_MUDURU') {
            return redirect()->route('dashboard.il');
        } elseif ($user->rol && $user->rol->kod === 'ILCE_MUDURU') {
            return redirect()->route('dashboard.ilce');
        }

        return view('dashboard');
    }
}
