<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AktifKontrol
{
    public function handle(Request $request, Closure $next): Response
    {
        $kullanici = null;

        if (auth()->guard('super_admin')->check()) {
            $kullanici = auth()->guard('super_admin')->user();
        } elseif (auth()->guard('kullanici')->check()) {
            $kullanici = auth()->guard('kullanici')->user();
        }

        if ($kullanici && !$kullanici->aktif) {
            auth()->guard('super_admin')->logout();
            auth()->guard('kullanici')->logout();
            return redirect()->route('login')->with('error', 'Hesabiniz pasif durumda.');
        }

        return $next($request);
    }
}
