<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\IpKontrol;
use App\Models\CihazLog;
use Illuminate\Support\Facades\Auth;

class IpKontrol
{
    public function handle(Request $request, Closure $next)
    {
        $ip = $request->ip();

        // IP kontrolu (aktif kayit varsa)
        $ipKayit = IpKontrol::where('ip_adresi', $ip)->where('aktif', true)->first();

        // Genel IP kontrolu (0.0.0.0 = herkese izin)
        $genelIzin = IpKontrol::where('ip_adresi', '0.0.0.0')->where('aktif', true)->where('tur', 'izinli')->first();

        // Kullanici bazli IP kontrolu
        $userId = Auth::guard('kullanici')->id() ?? Auth::guard('super_admin')->id();
        $kullaniciIp = null;
        if ($userId) {
            $kullaniciIp = IpKontrol::where('kullanici_id', $userId)->where('aktif', true)->first();
        }

        // Eger IP engelli ise
        if ($ipKayit && $ipKayit->tur === 'engelli') {
            return redirect()->route('ip.yasak');
        }

        // Eger genel izin yoksa ve kullanici bazli izin yoksa
        if (!$genelIzin && !$kullaniciIp) {
            return redirect()->route('ip.yasak');
        }

        // Cihaz tespiti
        $userAgent = $request->userAgent();
        $cihazTuru = $this->cihazTespit($userAgent);
        $os = $this->osTespit($userAgent);
        $tarayici = $this->tarayiciTespit($userAgent);

        // Loglama (KVKK uyumlu - anonim)
        CihazLog::create([
            'kullanici_id' => $userId,
            'kullanici_turu' => Auth::guard('super_admin')->check() ? 'super_admin' : (Auth::guard('kullanici')->check() ? 'kullanici' : null),
            'ip_adresi' => $this->anonimIp($ip),
            'user_agent' => substr($userAgent, 0, 255),
            'cihaz_turu' => $cihazTuru,
            'isletim_sistemi' => $os,
            'tarayici' => $tarayici,
            'islem' => 'erisim',
            'zaman' => now(),
            'konum' => null,
        ]);

        return $next($request);
    }

    protected function cihazTespit($ua)
    {
        if (preg_match('/Mobile|Android|iPhone|iPod/', $ua)) return 'mobil';
        if (preg_match('/iPad|Tablet/', $ua)) return 'tablet';
        return 'masaustu';
    }

    protected function osTespit($ua)
    {
        if (preg_match('/Windows/', $ua)) return 'Windows';
        if (preg_match('/Mac/', $ua)) return 'MacOS';
        if (preg_match('/Linux/', $ua)) return 'Linux';
        if (preg_match('/Android/', $ua)) return 'Android';
        if (preg_match('/iOS/', $ua)) return 'iOS';
        return 'Bilinmiyor';
    }

    protected function tarayiciTespit($ua)
    {
        if (preg_match('/Chrome/', $ua)) return 'Chrome';
        if (preg_match('/Firefox/', $ua)) return 'Firefox';
        if (preg_match('/Safari/', $ua)) return 'Safari';
        if (preg_match('/Edge/', $ua)) return 'Edge';
        return 'Diger';
    }

    protected function anonimIp($ip)
    {
        $parts = explode('.', $ip);
        if (count($parts) === 4) {
            $parts[3] = 'xxx';
            return implode('.', $parts);
        }
        return substr($ip, 0, -3) . 'xxx';
    }
}
