<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\IpKontrol;
use App\Models\CihazLog;
use Illuminate\Support\Facades\Auth;

class IpKontrolMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $ip = $request->ip();

        // IP kontrolu (aktif kayit varsa)
        $ipKayit = IpKontrol::where('ip_adresi', $ip)->where('aktif', true)->first();

        if ($ipKayit && $ipKayit->tur === 'engelli') {
            return response()->json(['error' => 'Erisim engellendi.'], 403);
        }

        // Cihaz tespiti
        $userAgent = $request->userAgent();
        $cihazTuru = $this->cihazTespit($userAgent);
        $os = $this->osTespit($userAgent);
        $tarayici = $this->tarayiciTespit($userAgent);

        // Loglama (KVKK uyumlu - anonim)
        CihazLog::create([
            'kullanici_id' => Auth::guard('kullanici')->id() ?? Auth::guard('super_admin')->id(),
            'kullanici_turu' => Auth::guard('super_admin')->check() ? 'super_admin' : (Auth::guard('kullanici')->check() ? 'kullanici' : null),
            'ip_adresi' => $this->anonimIp($ip),
            'user_agent' => substr($userAgent, 0, 255),
            'cihaz_turu' => $cihazTuru,
            'isletim_sistemi' => $os,
            'tarayici' => $tarayici,
            'islem' => 'erisim',
            'zaman' => now(),
            'konum' => null, // GDPR/KVKK uyumlu - konum bilgisi yok
        ]);

        return $next($request);
    }

    protected function cihazTespit($ua)
    {
        if (preg_match('/Mobile|Android|iPhone|iPad|iPod/', $ua)) {
            return preg_match('/iPad|Tablet/', $ua) ? 'tablet' : 'mobil';
        }
        return 'masaustu';
    }

    protected function osTespit($ua)
    {
        if (preg_match('/Windows/', $ua)) return 'Windows';
        if (preg_match('/Mac/', $ua)) return 'MacOS';
        if (preg_match('/Linux/', $ua)) return 'Linux';
        if (preg_match('/Android/', $ua)) return 'Android';
        if (preg_match('/iOS/', $ua)) return 'iOS';
        return 'Bilinmiyor';
    }

    protected function tarayiciTespit($ua)
    {
        if (preg_match('/Chrome/', $ua)) return 'Chrome';
        if (preg_match('/Firefox/', $ua)) return 'Firefox';
        if (preg_match('/Safari/', $ua)) return 'Safari';
        if (preg_match('/Edge/', $ua)) return 'Edge';
        return 'Diger';
    }

    protected function anonimIp($ip)
    {
        // Son okteti maskele (KVKK uyumlu)
        $parts = explode('.', $ip);
        if (count($parts) === 4) {
            $parts[3] = 'xxx';
            return implode('.', $parts);
        }
        return substr($ip, 0, -3) . 'xxx';
    }
}
