<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HiyerarsiKontrol
{
    public function handle(Request $request, Closure $next, ...$seviyeler): Response
    {
        $kullanici = null;
        $turu = null;

        if (auth()->guard('super_admin')->check()) {
            $kullanici = auth()->guard('super_admin')->user();
            $turu = 'super_admin';
        } elseif (auth()->guard('kullanici')->check()) {
            $kullanici = auth()->guard('kullanici')->user();
            $turu = $kullanici->rol ? $kullanici->rol->seviye : null;
        }

        if (!$kullanici) {
            return redirect()->route('login')->with('error', 'Lutfen giris yapin.');
        }

        if ($turu === 'super_admin') {
            return $next($request);
        }

        if (!empty($seviyeler) && !in_array($turu, $seviyeler)) {
            return redirect()->route('dashboard')->with('error', 'Bu sayfaya erisim yetkiniz yok.');
        }

        return $next($request);
    }
}
