<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bakanlik extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'bakanliklar';
    protected $fillable = ['kod', 'ad', 'kisa_ad', 'telefon', 'email', 'adres', 'aktif'];
    protected $casts = ['aktif' => 'boolean'];

    public function ilMudurlukleri()
    {
        return $this->hasMany(IlMudurlugu::class, 'bakanlik_id');
    }

    public function kullanicilar()
    {
        return $this->hasMany(Kullanici::class, 'bakanlik_id');
    }
}
