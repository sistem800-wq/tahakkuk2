<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Kullanici extends Authenticatable
{
    use HasFactory, Notifiable, SoftDeletes;

    protected $table = 'kullanicilar';
    protected $fillable = [
        'kod', 'rol_id', 'bakanlik_id', 'il_mudurluk_id', 'merkez_id', 'ilce_mudurluk_id',
        'birim', // YENI: spor, muhasebe, personel
        'ad', 'soyad', 'tc_kimlik', 'email', 'telefon', 'sifre', 'aktif', 'durum',
        'email_dogrulama_kodu', 'email_dogrulama_zamani', 'email_dogrulandi',
        'sms_dogrulama_kodu', 'sms_dogrulama_zamani', 'telefon_dogrulandi',
        'google2fa_secret', 'iki_adimli_dogrulama', 'iki_adimli_yedek_kodlar',
        'son_giris', 'son_giris_ip', 'basarisiz_giris_sayisi', 'kilitli_tarih',
        'avatar', 'notlar'
    ];
    protected $hidden = [
        'sifre', 'remember_token', 'google2fa_secret', 'iki_adimli_yedek_kodlar',
        'email_dogrulama_kodu', 'sms_dogrulama_kodu'
    ];
    protected $casts = [
        'email_dogrulama_zamani' => 'datetime',
        'sms_dogrulama_zamani' => 'datetime',
        'son_giris' => 'datetime',
        'kilitli_tarih' => 'datetime',
        'iki_adimli_dogrulama' => 'boolean',
        'email_dogrulandi' => 'boolean',
        'telefon_dogrulandi' => 'boolean',
        'aktif' => 'boolean',
        'basarisiz_giris_sayisi' => 'integer',
    ];

    public function getAuthPassword()
    {
        return $this->sifre;
    }

    public function tamAd()
    {
        return $this->ad . ' ' . $this->soyad;
    }

    public function rol()
    {
        return $this->belongsTo(Rol::class, 'rol_id');
    }

    public function bakanlik()
    {
        return $this->belongsTo(Bakanlik::class, 'bakanlik_id');
    }

    public function ilMudurlugu()
    {
        return $this->belongsTo(IlMudurlugu::class, 'il_mudurluk_id');
    }

    public function merkez()
    {
        return $this->belongsTo(Merkez::class, 'merkez_id');
    }

    public function ilceMudurlugu()
    {
        return $this->belongsTo(IlceMudurlugu::class, 'ilce_mudurluk_id');
    }

    public function isSuperAdmin()
    {
        return $this->rol && $this->rol->kod === 'SUPER_ADMIN';
    }

    public function isBakanlik()
    {
        return $this->rol && $this->rol->kod === 'BAKANLIK';
    }

    public function isIlMuduru()
    {
        return $this->rol && $this->rol->kod === 'IL_MUDURU';
    }

    public function isMerkez()
    {
        return $this->rol && $this->rol->kod === 'MERKEZ';
    }

    public function isIlceMuduru()
    {
        return $this->rol && $this->rol->kod === 'ILCE_MUDURU';
    }

    public function hiyerarsiMetni()
    {
        if ($this->isBakanlik()) return 'Bakanlik: ' . ($this->bakanlik ? $this->bakanlik->ad : '-');
        if ($this->isIlMuduru()) return 'Il Mudurlugu: ' . ($this->ilMudurlugu ? $this->ilMudurlugu->ad : '-');
        if ($this->isMerkez()) return 'Merkez: ' . ($this->merkez ? $this->merkez->ad : '-');
        if ($this->isIlceMuduru()) return 'Ilce Mudurlugu: ' . ($this->ilceMudurlugu ? $this->ilceMudurlugu->ad : '-');
        return 'Bilinmiyor';
    }
}
