<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;

class SuperAdmin extends Authenticatable
{
    use HasFactory, Notifiable, SoftDeletes;

    protected $table = 'super_admins';
    protected $fillable = [
        'kod', 'ad', 'soyad', 'tc_kimlik', 'email', 'telefon', 'sifre',
        'aktif', 'email_dogrulama_zamani', 'telefon_dogrulama_zamani',
        'google2fa_secret', 'iki_adimli_dogrulama', 'son_giris', 'son_giris_ip'
    ];
    protected $hidden = ['sifre', 'remember_token', 'google2fa_secret'];
    protected $casts = [
        'email_dogrulama_zamani' => 'datetime',
        'telefon_dogrulama_zamani' => 'datetime',
        'son_giris' => 'datetime',
        'iki_adimli_dogrulama' => 'boolean',
        'aktif' => 'boolean',
    ];

    public function getAuthPassword()
    {
        return $this->sifre;
    }

    public function tamAd()
    {
        return $this->ad . ' ' . $this->soyad;
    }
}
