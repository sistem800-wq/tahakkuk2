<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IlceMudurlugu extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'ilce_mudurlukleri';
    protected $fillable = ['kod', 'il_mudurluk_id', 'ad', 'telefon', 'email', 'adres', 'aktif'];
    protected $casts = ['aktif' => 'boolean'];

    public function ilMudurlugu()
    {
        return $this->belongsTo(IlMudurlugu::class, 'il_mudurluk_id');
    }

    public function kullanicilar()
    {
        return $this->hasMany(Kullanici::class, 'ilce_mudurluk_id');
    }
}
