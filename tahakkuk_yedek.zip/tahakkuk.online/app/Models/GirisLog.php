<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GirisLog extends Model
{
    use HasFactory;

    protected $table = 'giris_loglari';
    protected $fillable = [
        'kullanici_turu', 'kullanici_id', 'islem', 'ip_adresi',
        'tarayici', 'isletim_sistemi', 'cihaz', 'konum', 'detay'
    ];
}
