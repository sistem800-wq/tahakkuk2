<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IpKontrol extends Model
{
    use HasFactory;

    protected $table = 'ip_kontrolleri';
    protected $fillable = ['ip_adresi', 'kullanici_id', 'tur', 'aciklama', 'aktif'];
    protected $casts = ['aktif' => 'boolean'];
}
