<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CihazLog extends Model
{
    use HasFactory;

    protected $table = 'cihaz_loglari';
    protected $fillable = [
        'kullanici_id', 'kullanici_turu', 'ip_adresi', 'user_agent',
        'cihaz_turu', 'isletim_sistemi', 'tarayici', 'islem', 'zaman', 'konum'
    ];
    protected $casts = ['zaman' => 'datetime'];
    public $timestamps = false;
}
