<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Rol extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'roller';
    protected $fillable = ['kod', 'ad', 'seviye', 'hierarchy', 'aciklama', 'izinler', 'aktif'];
    protected $casts = [
        'izinler' => 'array',
        'hierarchy' => 'integer',
        'aktif' => 'boolean',
    ];

    public function kullanicilar()
    {
        return $this->hasMany(Kullanici::class, 'rol_id');
    }
}
