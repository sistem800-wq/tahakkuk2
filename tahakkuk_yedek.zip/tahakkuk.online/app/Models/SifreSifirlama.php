<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SifreSifirlama extends Model
{
    use HasFactory;

    protected $table = 'sifre_sifirlama';
    protected $fillable = ['email', 'token', 'kullanici_turu', 'olusturulma_zamani', 'son_kullanma_zamani', 'kullanildi'];
    protected $casts = [
        'olusturulma_zamani' => 'datetime',
        'son_kullanma_zamani' => 'datetime',
        'kullanildi' => 'boolean',
    ];
}
