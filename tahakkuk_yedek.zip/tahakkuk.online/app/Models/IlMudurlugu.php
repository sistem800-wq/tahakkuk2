<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IlMudurlugu extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'il_mudurlukleri';
    protected $fillable = ['kod', 'bakanlik_id', 'ad', 'plaka_kodu', 'telefon', 'email', 'adres', 'aktif'];
    protected $casts = ['aktif' => 'boolean'];

    public function bakanlik()
    {
        return $this->belongsTo(Bakanlik::class, 'bakanlik_id');
    }

    public function merkezler()
    {
        return $this->hasMany(Merkez::class, 'il_mudurluk_id');
    }

    public function ilceMudurlukleri()
    {
        return $this->hasMany(IlceMudurlugu::class, 'il_mudurluk_id');
    }

    public function kullanicilar()
    {
        return $this->hasMany(Kullanici::class, 'il_mudurluk_id');
    }
}
