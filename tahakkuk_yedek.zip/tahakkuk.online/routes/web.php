<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\SifreSifirlamaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\BakanlikDashboardController;
use App\Http\Controllers\IlDashboardController;
use App\Http\Controllers\IlceDashboardController;

// IP Yasak Sayfasi
Route::get('/ip-yasak', function() {
    return view('auth.ip-yasak', ['ip' => request()->ip()]);
})->name('ip.yasak');

// Super Admin Giris
Route::get('/superadmin', [LoginController::class, 'showSuperAdminLoginForm'])->name('superadmin.login');
Route::post('/superadmin/login', [LoginController::class, 'superAdminLogin'])->name('superadmin.login.post');

// Sifre Sifirlama
Route::get('/sifre-sifirlama', [SifreSifirlamaController::class, 'showSifreSifirlamaForm'])->name('sifre.sifirlama');
Route::post('/sifre-sifirlama/email', [SifreSifirlamaController::class, 'sendToken'])->name('sifre.sifirlama.email');
Route::post('/sifre-sifirlama/sms', [SifreSifirlamaController::class, 'sendSmsToken'])->name('sifre.sifirlama.sms');
Route::get('/sifre-sifirlama/{token}', [SifreSifirlamaController::class, 'showYeniSifreForm'])->name('sifre.sifirlama.token');
Route::post('/sifre-guncelle', [SifreSifirlamaController::class, 'updateSifre'])->name('sifre.guncelle');

// Normal Kullanici Giris
Route::middleware(['guest'])->group(function () {
    Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.post');
});

// Auth gerektiren route'lar
Route::middleware(['auth:super_admin,kullanici'])->group(function () {
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

    // Her kullanici turu icin ayri dashboard
    Route::get('/dashboard/bakanlik', [BakanlikDashboardController::class, 'index'])->name('dashboard.bakanlik')->middleware('hiyerarsi:bakanlik');
    Route::get('/dashboard/il', [IlDashboardController::class, 'index'])->name('dashboard.il')->middleware('hiyerarsi:il');
    Route::get('/dashboard/ilce', [IlceDashboardController::class, 'index'])->name('dashboard.ilce')->middleware('hiyerarsi:ilce');

    // Genel dashboard (yonlendirme)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});
