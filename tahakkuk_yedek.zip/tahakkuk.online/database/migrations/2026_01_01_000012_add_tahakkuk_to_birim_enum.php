<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Mevcut enum degerlerini kontrol et
        $mevcut = DB::select("SHOW COLUMNS FROM kullanicilar WHERE Field = 'birim'");
        if (!empty($mevcut)) {
            $type = $mevcut[0]->Type;
            // Eger tahakkuk yoksa ekle
            if (strpos($type, 'tahakkuk') === false) {
                DB::statement("ALTER TABLE kullanicilar MODIFY COLUMN birim ENUM('spor', 'muhasebe', 'personel', 'tahakkuk') NULL");
            }
        }
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE kullanicilar MODIFY COLUMN birim ENUM('spor', 'muhasebe', 'personel') NULL");
    }
};
