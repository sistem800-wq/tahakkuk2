<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roller', function (Blueprint $table) {
            $table->id();
            $table->string('kod', 20)->unique();
            $table->string('ad', 50)->unique();
            $table->string('seviye', 20);
            $table->integer('hierarchy')->default(0);
            $table->text('aciklama')->nullable();
            $table->json('izinler')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roller');
    }
};
