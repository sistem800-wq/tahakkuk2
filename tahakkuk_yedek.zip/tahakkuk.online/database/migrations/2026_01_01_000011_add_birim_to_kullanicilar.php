<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('kullanicilar', function (Blueprint $table) {
            // Once servis varsa kaldir
            if (Schema::hasColumn('kullanicilar', 'servis')) {
                $table->dropColumn('servis');
            }
            // Birim ekle
            $table->enum('birim', ['spor', 'muhasebe', 'personel'])->nullable()->after('ilce_mudurluk_id');
        });
    }

    public function down(): void
    {
        Schema::table('kullanicilar', function (Blueprint $table) {
            $table->dropColumn('birim');
        });
    }
};
