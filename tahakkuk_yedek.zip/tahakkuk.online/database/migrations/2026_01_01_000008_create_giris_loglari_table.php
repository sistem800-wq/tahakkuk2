<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('giris_loglari', function (Blueprint $table) {
            $table->id();
            $table->string('kullanici_turu', 20);
            $table->unsignedBigInteger('kullanici_id');
            $table->string('islem', 20);
            $table->string('ip_adresi', 45);
            $table->string('tarayici', 255)->nullable();
            $table->string('isletim_sistemi', 100)->nullable();
            $table->string('cihaz', 100)->nullable();
            $table->string('konum', 100)->nullable();
            $table->text('detay')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('giris_loglari');
    }
};
