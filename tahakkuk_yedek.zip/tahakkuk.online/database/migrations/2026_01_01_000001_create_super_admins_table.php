<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('super_admins', function (Blueprint $table) {
            $table->id();
            $table->string('kod', 20)->unique();
            $table->string('ad', 50);
            $table->string('soyad', 50);
            $table->string('tc_kimlik', 11)->unique();
            $table->string('email', 100)->unique();
            $table->string('telefon', 20)->nullable();
            $table->string('sifre');
            $table->boolean('aktif')->default(true);
            $table->boolean('email_dogrulandi')->default(false);
            $table->boolean('telefon_dogrulandi')->default(false);
            $table->timestamp('email_dogrulama_zamani')->nullable();
            $table->timestamp('telefon_dogrulama_zamani')->nullable();
            $table->string('google2fa_secret')->nullable();
            $table->boolean('iki_adimli_dogrulama')->default(false);
            $table->timestamp('son_giris')->nullable();
            $table->string('son_giris_ip', 45)->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('super_admins');
    }
};
