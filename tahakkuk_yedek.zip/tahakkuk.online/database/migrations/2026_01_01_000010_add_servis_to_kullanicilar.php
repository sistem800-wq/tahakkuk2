<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('kullanicilar', function (Blueprint $table) {
            $table->enum('servis', ['spor', 'muhasebe', 'personel'])->nullable()->after('ilce_mudurluk_id');
        });
    }

    public function down(): void
    {
        Schema::table('kullanicilar', function (Blueprint $table) {
            $table->dropColumn('servis');
        });
    }
};
