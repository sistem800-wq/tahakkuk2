<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('sifre_sifirlama')) {
            Schema::create('sifre_sifirlama', function (Blueprint $table) {
                $table->id();
                $table->string('email');
                $table->string('token');
                $table->timestamp('olusturulma_tarihi')->nullable();
                $table->timestamp('son_kullanma_tarihi')->nullable();
                $table->boolean('kullanildi')->default(false);
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('sifre_sifirlama');
    }
};
