<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kullanicilar', function (Blueprint $table) {
            $table->id();
            $table->string('kod', 30)->unique();
            $table->foreignId('rol_id')->constrained('roller');
            $table->foreignId('bakanlik_id')->nullable()->constrained('bakanliklar');
            $table->foreignId('il_mudurluk_id')->nullable()->constrained('il_mudurlukleri');
            $table->foreignId('merkez_id')->nullable()->constrained('merkezler');
            $table->foreignId('ilce_mudurluk_id')->nullable()->constrained('ilce_mudurlukleri');
            $table->string('ad', 50);
            $table->string('soyad', 50);
            $table->string('tc_kimlik', 11)->unique();
            $table->string('email', 100)->unique();
            $table->string('telefon', 20)->nullable();
            $table->string('sifre');
            $table->boolean('aktif')->default(true);
            $table->enum('durum', ['beklemede', 'onaylandi', 'reddedildi', 'askiya_alindi'])->default('beklemede');
            $table->string('email_dogrulama_kodu', 10)->nullable();
            $table->timestamp('email_dogrulama_zamani')->nullable();
            $table->boolean('email_dogrulandi')->default(false);
            $table->string('sms_dogrulama_kodu', 10)->nullable();
            $table->timestamp('sms_dogrulama_zamani')->nullable();
            $table->boolean('telefon_dogrulandi')->default(false);
            $table->string('google2fa_secret')->nullable();
            $table->boolean('iki_adimli_dogrulama')->default(false);
            $table->string('iki_adimli_yedek_kodlar', 255)->nullable();
            $table->timestamp('son_giris')->nullable();
            $table->string('son_giris_ip', 45)->nullable();
            $table->integer('basarisiz_giris_sayisi')->default(0);
            $table->timestamp('kilitli_tarih')->nullable();
            $table->string('avatar', 255)->nullable();
            $table->text('notlar')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kullanicilar');
    }
};
