<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bakanliklar', function (Blueprint $table) {
            $table->id();
            $table->string('kod', 20)->unique();
            $table->string('ad', 100)->unique();
            $table->string('kisa_ad', 20)->nullable();
            $table->string('telefon', 20)->nullable();
            $table->string('email', 100)->nullable();
            $table->text('adres')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bakanliklar');
    }
};
