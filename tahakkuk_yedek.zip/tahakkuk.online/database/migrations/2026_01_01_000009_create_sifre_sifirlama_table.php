<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sifre_sifirlama', function (Blueprint $table) {
            $table->id();
            $table->string('email', 100);
            $table->string('token', 100)->unique();
            $table->string('kullanici_turu', 20);
            $table->timestamp('olusturulma_zamani')->nullable();
            $table->timestamp('son_kullanma_zamani')->nullable();
            $table->boolean('kullanildi')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sifre_sifirlama');
    }
};
