<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('il_mudurlukleri', function (Blueprint $table) {
            $table->id();
            $table->string('kod', 20)->unique();
            $table->foreignId('bakanlik_id')->constrained('bakanliklar');
            $table->string('ad', 100);
            $table->string('plaka_kodu', 3)->nullable();
            $table->string('telefon', 20)->nullable();
            $table->string('email', 100)->nullable();
            $table->text('adres')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('il_mudurlukleri');
    }
};
