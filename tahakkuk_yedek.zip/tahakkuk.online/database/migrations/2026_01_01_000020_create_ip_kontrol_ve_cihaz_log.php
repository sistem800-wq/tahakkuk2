<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ip_kontrolleri', function (Blueprint $table) {
            $table->id();
            $table->string('ip_adresi', 45)->index();
            $table->string('tur', 20)->default('izinli'); // izinli, engelli
            $table->string('aciklama')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
        });

        Schema::create('cihaz_loglari', function (Blueprint $table) {
            $table->id();
            $table->foreignId('kullanici_id')->nullable()->constrained('kullanicilar')->onDelete('set null');
            $table->string('kullanici_turu', 20)->nullable(); // super_admin, kullanici
            $table->string('ip_adresi', 45)->index();
            $table->string('user_agent')->nullable();
            $table->string('cihaz_turu', 20)->nullable(); // mobil, masaustu, tablet
            $table->string('isletim_sistemi', 50)->nullable();
            $table->string('tarayici', 50)->nullable();
            $table->string('islem', 50)->default('giris'); // giris, cikis, hatali_giris
            $table->timestamp('zaman');
            $table->string('konum', 100)->nullable(); // sehir, ulke (anonim)
            $table->index(['kullanici_id', 'zaman']);
            $table->index(['ip_adresi', 'zaman']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cihaz_loglari');
        Schema::dropIfExists('ip_kontrolleri');
    }
};
