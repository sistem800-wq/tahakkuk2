<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Rol;

class RolSeeder extends Seeder
{
    public function run(): void
    {
        $roller = [
            ['kod' => 'SUPER_ADMIN', 'ad' => 'Super Admin', 'seviye' => 'system', 'hierarchy' => 1, 'aciklama' => 'Sistem Yoneticisi', 'izinler' => json_encode(['*']), 'aktif' => true],
            ['kod' => 'BAKANLIK', 'ad' => 'Bakanlik', 'seviye' => 'bakanlik', 'hierarchy' => 2, 'aciklama' => 'Bakanlik Yetkilisi', 'izinler' => json_encode(['bakanlik.*']), 'aktif' => true],
            ['kod' => 'IL_MUDURU', 'ad' => 'Il Muduru', 'seviye' => 'il', 'hierarchy' => 3, 'aciklama' => 'Il Muduru', 'izinler' => json_encode(['il.*']), 'aktif' => true],
            ['kod' => 'MERKEZ', 'ad' => 'Merkez', 'seviye' => 'merkez', 'hierarchy' => 4, 'aciklama' => 'Merkez Yetkilisi', 'izinler' => json_encode(['merkez.*']), 'aktif' => true],
            ['kod' => 'ILCE_MUDURU', 'ad' => 'Ilce Muduru', 'seviye' => 'ilce', 'hierarchy' => 5, 'aciklama' => 'Ilce Muduru', 'izinler' => json_encode(['ilce.*']), 'aktif' => true],
        ];

        foreach ($roller as $rol) {
            Rol::updateOrCreate(
                ['kod' => $rol['kod']],
                $rol
            );
        }
    }
}
