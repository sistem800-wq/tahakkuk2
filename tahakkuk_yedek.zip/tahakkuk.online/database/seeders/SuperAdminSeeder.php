<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SuperAdmin;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    public function run(): void
    {
        SuperAdmin::create([
            'kod' => '2026-00-00-00-01',
            'ad' => 'Super',
            'soyad' => 'Admin',
            'tc_kimlik' => '11111111111',
            'email' => 'superadmin@tahakkuk.online',
            'telefon' => '0500 111 1111',
            'sifre' => Hash::make('SuperAdmin2026!'),
            'aktif' => true,
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);
    }
}
