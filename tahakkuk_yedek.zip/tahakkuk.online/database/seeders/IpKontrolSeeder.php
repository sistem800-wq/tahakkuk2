<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\IpKontrol;

class IpKontrolSeeder extends Seeder
{
    public function run(): void
    {
        // Ornek: Tum IP'lere izin ver (0.0.0.0 = herkes)
        IpKontrol::updateOrCreate(
            ['ip_adresi' => '0.0.0.0'],
            [
                'tur' => 'izinli',
                'aciklama' => 'Tum IP adreslerine izin ver (ornek mod)',
                'aktif' => true,
            ]
        );
    }
}
