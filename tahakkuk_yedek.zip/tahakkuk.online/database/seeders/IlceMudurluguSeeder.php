<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\IlceMudurlugu;
use App\Models\IlMudurlugu;

class IlceMudurluguSeeder extends Seeder
{
    public function run(): void
    {
        $istanbul = IlMudurlugu::where('kod', '34')->first();
        $izmir = IlMudurlugu::where('kod', '35')->first();
        $ankara = IlMudurlugu::where('kod', '06')->first();
        $adana = IlMudurlugu::where('kod', '01')->first();

        if (!$istanbul) {
            echo "Istanbul bulunamadi!\n";
            return;
        }

        $ilceler = [
            ['kod' => '34-01', 'il_mudurluk_id' => $istanbul->id, 'ad' => 'Sisli Ilce Spor Mudurlugu', 'telefon' => '0212-111-1111'],
            ['kod' => '34-02', 'il_mudurluk_id' => $istanbul->id, 'ad' => 'Kadikoy Ilce Spor Mudurlugu', 'telefon' => '0216-222-2222'],
            ['kod' => '34-03', 'il_mudurluk_id' => $istanbul->id, 'ad' => 'Besiktas Ilce Spor Mudurlugu', 'telefon' => '0212-333-3333'],
            ['kod' => '34-04', 'il_mudurluk_id' => $istanbul->id, 'ad' => 'Tuzla Ilce Spor Mudurlugu', 'telefon' => '0216-444-4444'],
            ['kod' => '34-05', 'il_mudurluk_id' => $istanbul->id, 'ad' => 'Bagcilar Ilce Spor Mudurlugu', 'telefon' => '0212-555-5555'],
        ];

        if ($izmir) {
            $ilceler[] = ['kod' => '35-01', 'il_mudurluk_id' => $izmir->id, 'ad' => 'Konak Ilce Spor Mudurlugu', 'telefon' => '0232-111-1111'];
            $ilceler[] = ['kod' => '35-02', 'il_mudurluk_id' => $izmir->id, 'ad' => 'Karsiyaka Ilce Spor Mudurlugu', 'telefon' => '0232-222-2222'];
        }

        if ($ankara) {
            $ilceler[] = ['kod' => '06-01', 'il_mudurluk_id' => $ankara->id, 'ad' => 'Cankaya Ilce Spor Mudurlugu', 'telefon' => '0312-111-1111'];
            $ilceler[] = ['kod' => '06-02', 'il_mudurluk_id' => $ankara->id, 'ad' => 'Kecioren Ilce Spor Mudurlugu', 'telefon' => '0312-222-2222'];
        }

        if ($adana) {
            $ilceler[] = ['kod' => '01-01', 'il_mudurluk_id' => $adana->id, 'ad' => 'Seyhan Ilce Spor Mudurlugu', 'telefon' => '0322-111-1111'];
        }

        foreach ($ilceler as $ilce) {
            $mevcut = IlceMudurlugu::where('kod', $ilce['kod'])->first();
            $data = array_merge($ilce, [
                'email' => strtolower(str_replace(' ', '.', $ilce['ad'])) . '@tahakkuk.online',
                'adres' => $ilce['ad'],
                'aktif' => true,
            ]);

            if ($mevcut) {
                $mevcut->update($data);
            } else {
                IlceMudurlugu::create($data);
            }
        }
    }
}
