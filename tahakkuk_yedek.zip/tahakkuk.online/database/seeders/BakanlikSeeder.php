<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Bakanlik;

class BakanlikSeeder extends Seeder
{
    public function run(): void
    {
        // Mevcut kaydi bul veya olustur
        $bakanlik = Bakanlik::where('ad', 'Genclik ve Spor Bakanligi')->first();

        if ($bakanlik) {
            $bakanlik->update([
                'kod' => 'GSB',
                'kisa_ad' => 'GSB',
                'telefon' => '0312-123-4567',
                'email' => 'info@gsb.gov.tr',
                'adres' => 'Ankara',
                'aktif' => true,
            ]);
        } else {
            Bakanlik::create([
                'kod' => 'GSB',
                'ad' => 'Genclik ve Spor Bakanligi',
                'kisa_ad' => 'GSB',
                'telefon' => '0312-123-4567',
                'email' => 'info@gsb.gov.tr',
                'adres' => 'Ankara',
                'aktif' => true,
            ]);
        }
    }
}
