<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kullanici;
use App\Models\SuperAdmin;
use App\Models\Rol;
use App\Models\Bakanlik;
use App\Models\IlMudurlugu;
use App\Models\IlceMudurlugu;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $rolBakanlik = Rol::where('kod', 'BAKANLIK')->first();
        $rolIlMuduru = Rol::where('kod', 'IL_MUDURU')->first();
        $rolIlceMuduru = Rol::where('kod', 'ILCE_MUDURU')->first();

        $bakanlik = Bakanlik::where('kod', 'GSB')->first();
        $istanbul = IlMudurlugu::where('kod', '34')->first();
        $ankara = IlMudurlugu::where('kod', '06')->first();
        $sisli = IlceMudurlugu::where('kod', '34-01')->first();

        // Super Admin
        SuperAdmin::updateOrCreate(
            ['email' => 'superadmin@tahakkuk.online'],
            [
                'kod' => 'SA001',
                'ad' => 'Super',
                'soyad' => 'Admin',
                'tc_kimlik' => '11111111111',
                'telefon' => '5320000000',
                'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true,
            ]
        );

        // BAKANLIK + Birim
        Kullanici::updateOrCreate(
            ['email' => 'bakanlik.spor@tahakkuk.online'],
            [
                'kod' => 'BK_SP', 'rol_id' => $rolBakanlik?->id, 'bakanlik_id' => $bakanlik?->id,
                'birim' => 'spor', 'tc_kimlik' => '22222222221',
                'ad' => 'Bakanlik Spor', 'soyad' => 'Yetkilisi',
                'telefon' => '5321111111', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'bakanlik.muhasebe@tahakkuk.online'],
            [
                'kod' => 'BK_MH', 'rol_id' => $rolBakanlik?->id, 'bakanlik_id' => $bakanlik?->id,
                'birim' => 'muhasebe', 'tc_kimlik' => '22222222222',
                'ad' => 'Bakanlik Muhasebe', 'soyad' => 'Yetkilisi',
                'telefon' => '5321111112', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'bakanlik.tahakkuk@tahakkuk.online'],
            [
                'kod' => 'BK_TH', 'rol_id' => $rolBakanlik?->id, 'bakanlik_id' => $bakanlik?->id,
                'birim' => 'tahakkuk', 'tc_kimlik' => '22222222223',
                'ad' => 'Bakanlik Tahakkuk', 'soyad' => 'Yetkilisi',
                'telefon' => '5321111113', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'bakanlik.personel@tahakkuk.online'],
            [
                'kod' => 'BK_PR', 'rol_id' => $rolBakanlik?->id, 'bakanlik_id' => $bakanlik?->id,
                'birim' => 'personel', 'tc_kimlik' => '22222222224',
                'ad' => 'Bakanlik Personel', 'soyad' => 'Yetkilisi',
                'telefon' => '5321111114', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );

        // ISTANBUL IL + Birim
        Kullanici::updateOrCreate(
            ['email' => 'istanbul.spor@tahakkuk.online'],
            [
                'kod' => 'IL34_SP', 'rol_id' => $rolIlMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'birim' => 'spor', 'tc_kimlik' => '33333333331',
                'ad' => 'Istanbul Spor', 'soyad' => 'Muduru',
                'telefon' => '5322222221', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'istanbul.muhasebe@tahakkuk.online'],
            [
                'kod' => 'IL34_MH', 'rol_id' => $rolIlMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'birim' => 'muhasebe', 'tc_kimlik' => '33333333332',
                'ad' => 'Istanbul Muhasebe', 'soyad' => 'Muduru',
                'telefon' => '5322222222', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'istanbul.tahakkuk@tahakkuk.online'],
            [
                'kod' => 'IL34_TH', 'rol_id' => $rolIlMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'birim' => 'tahakkuk', 'tc_kimlik' => '33333333333',
                'ad' => 'Istanbul Tahakkuk', 'soyad' => 'Muduru',
                'telefon' => '5322222223', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'istanbul.personel@tahakkuk.online'],
            [
                'kod' => 'IL34_PR', 'rol_id' => $rolIlMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'birim' => 'personel', 'tc_kimlik' => '33333333334',
                'ad' => 'Istanbul Personel', 'soyad' => 'Muduru',
                'telefon' => '5322222224', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );

        // ANKARA IL + Birim
        Kullanici::updateOrCreate(
            ['email' => 'ankara.spor@tahakkuk.online'],
            [
                'kod' => 'IL06_SP', 'rol_id' => $rolIlMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $ankara?->id, 'birim' => 'spor', 'tc_kimlik' => '44444444441',
                'ad' => 'Ankara Spor', 'soyad' => 'Muduru',
                'telefon' => '5323333331', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );

        // SISLI ILCE + Birim
        Kullanici::updateOrCreate(
            ['email' => 'sisli.spor@tahakkuk.online'],
            [
                'kod' => 'IC3401_SP', 'rol_id' => $rolIlceMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'ilce_mudurluk_id' => $sisli?->id,
                'birim' => 'spor', 'tc_kimlik' => '55555555551',
                'ad' => 'Sisli Spor', 'soyad' => 'Muduru',
                'telefon' => '5324444441', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'sisli.muhasebe@tahakkuk.online'],
            [
                'kod' => 'IC3401_MH', 'rol_id' => $rolIlceMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'ilce_mudurluk_id' => $sisli?->id,
                'birim' => 'muhasebe', 'tc_kimlik' => '55555555552',
                'ad' => 'Sisli Muhasebe', 'soyad' => 'Muduru',
                'telefon' => '5324444442', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'sisli.tahakkuk@tahakkuk.online'],
            [
                'kod' => 'IC3401_TH', 'rol_id' => $rolIlceMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'ilce_mudurluk_id' => $sisli?->id,
                'birim' => 'tahakkuk', 'tc_kimlik' => '55555555553',
                'ad' => 'Sisli Tahakkuk', 'soyad' => 'Muduru',
                'telefon' => '5324444443', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
        Kullanici::updateOrCreate(
            ['email' => 'sisli.personel@tahakkuk.online'],
            [
                'kod' => 'IC3401_PR', 'rol_id' => $rolIlceMuduru?->id, 'bakanlik_id' => $bakanlik?->id,
                'il_mudurluk_id' => $istanbul?->id, 'ilce_mudurluk_id' => $sisli?->id,
                'birim' => 'personel', 'tc_kimlik' => '55555555554',
                'ad' => 'Sisli Personel', 'soyad' => 'Muduru',
                'telefon' => '5324444444', 'sifre' => Hash::make('Tahakkuk2024!'),
                'aktif' => true, 'durum' => 'onaylandi',
            ]
        );
    }
}
