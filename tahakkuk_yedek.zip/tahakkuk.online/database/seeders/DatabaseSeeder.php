<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolSeeder::class,
            BakanlikSeeder::class,
            IlMudurluguSeeder::class,
            IlceMudurluguSeeder::class,
            IpKontrolSeeder::class,
            UserSeeder::class,
        ]);
    }
}
