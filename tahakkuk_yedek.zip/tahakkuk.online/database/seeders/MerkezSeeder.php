<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Merkez;

class MerkezSeeder extends Seeder
{
    public function run(): void
    {
        $merkezler = [
            ['il_mudurluk_id' => 1, 'kod' => '2026-01-01-01-00', 'ad' => 'Istanbul Merkez Spor Kompleksi', 'telefon' => '0212 111 2222', 'email' => 'merkez@istanbul.gsb.gov.tr', 'adres' => 'Istanbul Merkez', 'aktif' => true],
            ['il_mudurluk_id' => 1, 'kod' => '2026-01-01-02-00', 'ad' => 'Istanbul Anadolu Yakasi Spor Merkezi', 'telefon' => '0216 222 3333', 'email' => 'anadolu@istanbul.gsb.gov.tr', 'adres' => 'Istanbul Anadolu', 'aktif' => true],
        ];

        foreach ($merkezler as $merkez) {
            Merkez::create($merkez);
        }
    }
}
