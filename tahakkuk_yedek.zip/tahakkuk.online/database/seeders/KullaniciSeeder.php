<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kullanici;
use Illuminate\Support\Facades\Hash;

class KullaniciSeeder extends Seeder
{
    public function run(): void
    {
        // Bakanlik kullanicisi
        Kullanici::create([
            'kod' => '2026-01-00-00-01',
            'rol_id' => 2,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => null,
            'merkez_id' => null,
            'ilce_mudurluk_id' => null,
            'ad' => 'Bakanlik',
            'soyad' => 'Yetkilisi',
            'tc_kimlik' => '22222222222',
            'email' => 'bakanlik@tahakkuk.online',
            'telefon' => '0500 222 2222',
            'sifre' => Hash::make('Bakanlik2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Istanbul Il Muduru
        Kullanici::create([
            'kod' => '2026-01-01-00-01',
            'rol_id' => 3,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 1,
            'merkez_id' => null,
            'ilce_mudurluk_id' => null,
            'ad' => 'Istanbul',
            'soyad' => 'Muduru',
            'tc_kimlik' => '33333333333',
            'email' => 'istanbul@tahakkuk.online',
            'telefon' => '0500 333 3333',
            'sifre' => Hash::make('Istanbul2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Ankara Il Muduru
        Kullanici::create([
            'kod' => '2026-01-02-00-01',
            'rol_id' => 3,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 2,
            'merkez_id' => null,
            'ilce_mudurluk_id' => null,
            'ad' => 'Ankara',
            'soyad' => 'Muduru',
            'tc_kimlik' => '44444444444',
            'email' => 'ankara@tahakkuk.online',
            'telefon' => '0500 444 4444',
            'sifre' => Hash::make('Ankara2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Merkez kullanicisi (ID: 1)
        Kullanici::create([
            'kod' => '2026-01-01-01-01',
            'rol_id' => 4,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 1,
            'merkez_id' => 1,
            'ilce_mudurluk_id' => null,
            'ad' => 'Merkez',
            'soyad' => 'Yetkilisi',
            'tc_kimlik' => '55555555555',
            'email' => 'merkez@tahakkuk.online',
            'telefon' => '0500 555 5555',
            'sifre' => Hash::make('Merkez2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Sisli Ilce Muduru (ID: 1)
        Kullanici::create([
            'kod' => '2026-01-01-02-01',
            'rol_id' => 5,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 1,
            'merkez_id' => null,
            'ilce_mudurluk_id' => 1,
            'ad' => 'Sisli',
            'soyad' => 'Muduru',
            'tc_kimlik' => '66666666666',
            'email' => 'sisli@tahakkuk.online',
            'telefon' => '0500 666 6666',
            'sifre' => Hash::make('Sisli2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Tuzla Ilce Muduru (ID: 2)
        Kullanici::create([
            'kod' => '2026-01-01-03-01',
            'rol_id' => 5,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 1,
            'merkez_id' => null,
            'ilce_mudurluk_id' => 2,
            'ad' => 'Tuzla',
            'soyad' => 'Muduru',
            'tc_kimlik' => '77777777777',
            'email' => 'tuzla@tahakkuk.online',
            'telefon' => '0500 777 7777',
            'sifre' => Hash::make('Tuzla2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);

        // Bagcilar Ilce Muduru (ID: 3)
        Kullanici::create([
            'kod' => '2026-01-01-04-01',
            'rol_id' => 5,
            'bakanlik_id' => 1,
            'il_mudurluk_id' => 1,
            'merkez_id' => null,
            'ilce_mudurluk_id' => 3,
            'ad' => 'Bagcilar',
            'soyad' => 'Muduru',
            'tc_kimlik' => '88888888888',
            'email' => 'bagcilar@tahakkuk.online',
            'telefon' => '0500 888 8888',
            'sifre' => Hash::make('Bagcilar2026!'),
            'aktif' => true,
            'durum' => 'onaylandi',
            'email_dogrulandi' => true,
            'telefon_dogrulandi' => true,
        ]);
    }
}
