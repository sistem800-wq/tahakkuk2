<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\IlMudurlugu;
use App\Models\Bakanlik;

class IlMudurluguSeeder extends Seeder
{
    public function run(): void
    {
        // Bakanligi bul (mevcut veya yeni)
        $bakanlik = Bakanlik::where('ad', 'Genclik ve Spor Bakanligi')->first();

        if (!$bakanlik) {
            echo "Bakanlik bulunamadi!\n";
            return;
        }

        $iller = [
            ['kod' => '34', 'ad' => 'Istanbul Il Spor Mudurlugu', 'plaka_kodu' => '34', 'telefon' => '0212-123-4567'],
            ['kod' => '35', 'ad' => 'Izmir Il Spor Mudurlugu', 'plaka_kodu' => '35', 'telefon' => '0232-123-4567'],
            ['kod' => '01', 'ad' => 'Adana Il Spor Mudurlugu', 'plaka_kodu' => '01', 'telefon' => '0322-123-4567'],
            ['kod' => '46', 'ad' => 'Kahramanmaras Il Spor Mudurlugu', 'plaka_kodu' => '46', 'telefon' => '0344-123-4567'],
            ['kod' => '41', 'ad' => 'Kocaeli Il Spor Mudurlugu', 'plaka_kodu' => '41', 'telefon' => '0262-123-4567'],
            ['kod' => '06', 'ad' => 'Ankara Il Spor Mudurlugu', 'plaka_kodu' => '06', 'telefon' => '0312-123-4567'],
            ['kod' => '07', 'ad' => 'Antalya Il Spor Mudurlugu', 'plaka_kodu' => '07', 'telefon' => '0242-123-4567'],
            ['kod' => '16', 'ad' => 'Bursa Il Spor Mudurlugu', 'plaka_kodu' => '16', 'telefon' => '0224-123-4567'],
        ];

        foreach ($iller as $il) {
            $mevcut = IlMudurlugu::where('kod', $il['kod'])->first();
            $data = array_merge($il, [
                'bakanlik_id' => $bakanlik->id,
                'email' => strtolower(str_replace(' ', '.', $il['ad'])) . '@tahakkuk.online',
                'adres' => $il['ad'],
                'aktif' => true,
            ]);

            if ($mevcut) {
                $mevcut->update($data);
            } else {
                IlMudurlugu::create($data);
            }
        }
    }
}
